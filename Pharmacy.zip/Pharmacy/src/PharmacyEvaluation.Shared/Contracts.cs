using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
namespace PharmacyEvaluation.Shared;

public static class Roles
{
    public const string Admin = "ADMIN";
    public const string Doctor = "DOCTOR";
}

public sealed class SignupRequest
{
    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public string? Role { get; set; }
}

public sealed class LoginRequest
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
}

public sealed class RefreshRequest
{
    public string RefreshToken { get; set; } = "";
}

public sealed class TokenResponse
{
    public string AccessToken { get; set; } = "";
    public string RefreshToken { get; set; } = "";
    public int UserId { get; set; }
    public string Role { get; set; } = "";
}

public sealed class ApiError
{
    public string Message { get; set; } = "";
    public IEnumerable<string>? Errors { get; set; }
}

public sealed class OrderItemRequest
{
    public int DrugId { get; set; }
    public int Quantity { get; set; }
}

public sealed class CreateOrderRequest
{
    public List<OrderItemRequest> Items { get; set; } = [];
}

public sealed class InventoryReservationItem
{
    public int DrugId { get; set; }
    public int Quantity { get; set; }
}

public sealed class ReservedDrug
{
    public int DrugId { get; set; }
    public string Name { get; set; } = "";
    public decimal Price { get; set; }
    public int Quantity { get; set; }
}

public sealed class PaymentResult
{
    public bool Succeeded { get; set; }
    public string? TransactionReference { get; set; }
    public string? FailureReason { get; set; }
}

public sealed class RazorpayCheckoutResponse
{
    public string KeyId { get; set; } = "";
    public string OrderId { get; set; } = "";
    public int Amount { get; set; }
    public string Currency { get; set; } = "INR";
}

public sealed class RazorpayVerificationRequest
{
    public string RazorpayOrderId { get; set; } = "";
    public string RazorpayPaymentId { get; set; } = "";
    public string RazorpaySignature { get; set; } = "";
}

public sealed class PaymentVerificationResponse
{
    public bool Succeeded { get; set; }
    public string? TransactionReference { get; set; }
}

public sealed class JwtOptions
{
    public string Secret { get; set; } = "";
    public string Issuer { get; set; } = "PharmacyManagementSystem";
    public string Audience { get; set; } = "PharmacyClients";
}

public static class AuthenticationRules
{
    public static bool IsValidSignup(SignupRequest? request) =>
        request is not null &&
        !string.IsNullOrWhiteSpace(request.Name) &&
        !string.IsNullOrWhiteSpace(request.Email) &&
        !string.IsNullOrWhiteSpace(request.Password) &&
        (
            string.IsNullOrWhiteSpace(request.Role) ||
            request.Role.Equals(Roles.Admin, StringComparison.OrdinalIgnoreCase) ||
            request.Role.Equals(Roles.Doctor, StringComparison.OrdinalIgnoreCase)
        );

    public static bool IsRefreshTokenActive(
        DateTime expiresAt,
        DateTime? revokedAt,
        DateTime now
    ) =>
        revokedAt is null && expiresAt > now;
}

public static class OrderRules
{
    public static bool IsValidNewOrder(CreateOrderRequest? request) =>
        request?.Items?.Count > 0 &&
        request.Items.All(x => x.DrugId > 0 && x.Quantity > 0);

    public static bool CanVerify(string status) =>
        status == "NEW";

    public static bool CanPickUp(string status) =>
        status == "VERIFIED";

    public static bool CanCancel(string status) =>
        status is "NEW" or "VERIFIED";
}

public static class InventoryRules
{
    public static bool CanReserve(
        int available,
        int requested,
        bool active
    ) =>
        active &&
        requested > 0 &&
        available >= requested;

    public static int RestoreQuantity(
        int current,
        int restored
    ) =>
        current + restored;
}

public static class GatewayAuthorizationRules
{
    public static bool IsPublic(string path) =>
        path is "auth/signup" or "auth/login" or "auth/refresh";
}

public sealed class JwtTokenService(IOptions<JwtOptions> options)
{
    private readonly JwtOptions _options = options.Value;

    public string Create(
        int userId,
        string role,
        string? name = null,
        string? email = null)
    {
        var key = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(_options.Secret)
        );

        var token = new JwtSecurityToken(
            _options.Issuer,
            _options.Audience,
            [
                new Claim(
                    ClaimTypes.NameIdentifier,
                    userId.ToString()
                ),
                new Claim(
                    ClaimTypes.Role,
                    role
                ),
                new Claim(
                    ClaimTypes.Name,
                    name ?? ""
                ),
                new Claim(
                    ClaimTypes.Email,
                    email ?? ""
                )
            ],
            DateTime.UtcNow,
            DateTime.UtcNow.AddMinutes(30),
            new SigningCredentials(
                key,
                SecurityAlgorithms.HmacSha256
            )
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}

public static class ExceptionMiddlewareExtensions
{
    public static IApplicationBuilder UsePharmacyExceptionHandling(
        this IApplicationBuilder app
    ) =>
        app.Use(async (context, next) =>
        {
            try
            {
                await next();
            }
            catch (Exception exception)
            {
                context.RequestServices
                    .GetRequiredService<Microsoft.Extensions.Logging.ILoggerFactory>()
                    .CreateLogger("PharmacyEvaluation.Exception")
                    .LogError(
                        exception,
                        "Unhandled API exception"
                    );

                context.Response.StatusCode =
                    StatusCodes.Status500InternalServerError;

                await context.Response.WriteAsJsonAsync(
                    new ApiError
                    {
                        Message = "An unexpected error occurred"
                    }
                );
            }
        });
}