using System.Net.Http.Headers;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PharmacyEvaluation.Shared;

namespace PharmacyEvaluation.ApiGateway.Controllers;

[ApiController, Route("api")]
public sealed class GatewayController(
    IHttpClientFactory clients,
    IConfiguration config
) : ControllerBase
{
    [AllowAnonymous, HttpPost("auth/signup"), HttpPost("auth/login"), HttpPost("auth/refresh")]
    public Task<IActionResult> ForwardPublic() =>
        Forward("auth");

    [Authorize, HttpPost("auth/logout")]
    public Task<IActionResult> Logout() =>
        Forward("auth");

    [Authorize]
    [HttpGet("drugs")]
    [HttpPost("drugs")]
    [HttpGet("drugs/{id:int}")]
    [HttpPut("drugs/{id:int}")]
    [HttpDelete("drugs/{id:int}")]
    [HttpGet("suppliers")]
    [HttpPost("suppliers")]
    [HttpPut("suppliers/{id:int}")]
    [HttpDelete("suppliers/{id:int}")]
    [HttpGet("reports/sales")]
    [HttpGet("reports/sales/download")]
    [HttpGet("reports/sales/print")]
    public Task<IActionResult> Inventory() =>
        Forward("inventory");

    [Authorize]
    [HttpGet("orders")]
    [HttpPost("orders")]
    [HttpGet("orders/{id:int}")]
    [HttpPut("orders/{id:int}/verify")]
    [HttpPut("orders/{id:int}/pickup")]
    [HttpPut("orders/{id:int}/cancel")]
    [HttpPost("orders/{id:int}/payment/razorpay")]
    [HttpPost("orders/{id:int}/payment/razorpay/verify")]
    [HttpPost("orders/{id:int}/payment/razorpay/fail")]
    public Task<IActionResult> Orders() =>
        Forward("orders");

    private async Task<IActionResult> Forward(string service)
    {
        var path = Request.Path + Request.QueryString;

        var url =
            config[$"Services:{service switch
            {
                "auth" => "UserAuthUrl",
                "orders" => "OrderUrl",
                _ => "InventoryUrl"
            }}"]!.TrimEnd('/') + path;

        using var request = new HttpRequestMessage(
            new HttpMethod(Request.Method),
            url
        );

        if (Request.ContentLength > 0)
        {
            request.Content = new StreamContent(Request.Body);

            if (!string.IsNullOrWhiteSpace(Request.ContentType))
                request.Content.Headers.ContentType =
                    MediaTypeHeaderValue.Parse(Request.ContentType);
        }

        if (Request.Headers.TryGetValue("Authorization", out var auth))
            request.Headers.TryAddWithoutValidation(
                "Authorization",
                auth.ToString()
            );

        using var response =
            await clients.CreateClient().SendAsync(request);

        var body =
            await response.Content.ReadAsByteArrayAsync();

        Response.StatusCode = (int)response.StatusCode;

        foreach (
            var header in response.Headers.Where(
                x => !IsHopByHop(x.Key)
            )
        )
        {
            Response.Headers[header.Key] =
                header.Value.ToArray();
        }

        var mediaType =
            response.Content.Headers.ContentType?.ToString()
            ?? "application/octet-stream";

        return File(body, mediaType);
    }

    private static bool IsHopByHop(string header) =>
        header.Equals(
            "Connection",
            StringComparison.OrdinalIgnoreCase
        ) ||
        header.Equals(
            "Keep-Alive",
            StringComparison.OrdinalIgnoreCase
        ) ||
        header.Equals(
            "Proxy-Authenticate",
            StringComparison.OrdinalIgnoreCase
        ) ||
        header.Equals(
            "Proxy-Authorization",
            StringComparison.OrdinalIgnoreCase
        ) ||
        header.Equals(
            "TE",
            StringComparison.OrdinalIgnoreCase
        ) ||
        header.Equals(
            "Trailer",
            StringComparison.OrdinalIgnoreCase
        ) ||
        header.Equals(
            "Transfer-Encoding",
            StringComparison.OrdinalIgnoreCase
        ) ||
        header.Equals(
            "Upgrade",
            StringComparison.OrdinalIgnoreCase
        );
}

[ApiController, Route("gateway/openapi.json")]
public sealed class GatewaySwaggerController(
    IHttpClientFactory clients,
    IConfiguration config
) : ControllerBase
{
    [AllowAnonymous, HttpGet]
    public async Task<IActionResult> Get()
    {
        var merged = new JsonObject
        {
            ["openapi"] = "3.0.1",
            ["info"] = new JsonObject
            {
                ["title"] = "Pharmacy Evaluation Gateway",
                ["version"] = "v1"
            },
            ["paths"] = new JsonObject(),
            ["security"] = new JsonArray(
                new JsonObject
                {
                    ["Bearer"] = new JsonArray()
                }
            ),
            ["components"] = new JsonObject
            {
                ["securitySchemes"] = new JsonObject
                {
                    ["Bearer"] = new JsonObject
                    {
                        ["type"] = "http",
                        ["scheme"] = "bearer",
                        ["bearerFormat"] = "JWT"
                    }
                }
            }
        };

        foreach (
            var key in new[]
            {
                "UserAuthUrl",
                "OrderUrl",
                "InventoryUrl"
            }
        )
        {
            var json =
                await clients.CreateClient().GetStringAsync(
                    config[$"Services:{key}"]!.TrimEnd('/')
                    + "/swagger/v1/swagger.json"
                );

            var doc =
                JsonNode.Parse(json)!.AsObject();

            foreach (var path in doc["paths"]!.AsObject())
            {
                merged["paths"]!.AsObject()[path.Key] =
                    path.Value?.DeepClone();
            }

            if (
                doc["components"]?["schemas"]
                is JsonObject schemas
            )
            {
                var target =
                    merged["components"]!.AsObject();

                target["schemas"] ??= new JsonObject();

                foreach (var schema in schemas)
                {
                    target["schemas"]!.AsObject()[schema.Key] =
                        schema.Value?.DeepClone();
                }
            }
        }

        return Content(
            merged.ToJsonString(),
            "application/json"
        );
    }
}