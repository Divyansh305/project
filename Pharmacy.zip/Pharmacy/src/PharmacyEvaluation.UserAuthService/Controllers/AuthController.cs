using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PharmacyEvaluation.Shared;

namespace PharmacyEvaluation.UserAuthService.Controllers;

[ApiController, Route("api/auth")]
public sealed class AuthController(AuthService service) : ControllerBase
{
    [HttpPost("signup")]
    public ActionResult<TokenResponse> Signup(
        [FromBody] SignupRequest r
    )
    {
        try
        {
            return Created(
                "",
                service.Signup(r)
            );
        }
        catch (InvalidOperationException)
        {
            return Conflict();
        }
        catch (ArgumentException e)
        {
            return BadRequest(
                new ApiError
                {
                    Message = e.Message
                }
            );
        }
    }

    [HttpPost("login")]
    public ActionResult<TokenResponse> Login(
        [FromBody] LoginRequest r
    )
    {
        try
        {
            return Ok(
                service.Login(r)
            );
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }
    }

    [Authorize, HttpPost("logout")]
    public IActionResult Logout(
        [FromBody] RefreshRequest r
    )
    {
        try
        {
            service.Logout(
                int.Parse(
                    User.FindFirstValue(
                        ClaimTypes.NameIdentifier
                    )!
                ),
                r.RefreshToken
            );

            return Ok();
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }
    }

    [HttpPost("refresh")]
    public ActionResult<TokenResponse> Refresh(
        [FromBody] RefreshRequest r
    )
    {
        try
        {
            return Ok(
                service.Refresh(r.RefreshToken)
            );
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }
    }
}