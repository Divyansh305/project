using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Cryptography;
using System.Text;
using System.Data.Entity;
using PharmacyEvaluation.Shared;

namespace PharmacyEvaluation.UserAuthService;

public sealed class Role
{
    [Key, Column("RoleId")]
    public int Id { get; set; }

    public string RoleName { get; set; } = "";
}

public class User
{
    [Key, Column("UserId")]
    public int Id { get; set; }

    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public int RoleId { get; set; }
    public DateTime CreatedAt { get; set; }
    public virtual Role? Role { get; set; }
}

public sealed class RefreshToken
{
    [Key, Column("RefreshTokenId")]
    public int Id { get; set; }

    public int UserId { get; set; }
    public string TokenHash { get; set; } = "";
    public DateTime IssuedAt { get; set; }
    public DateTime ExpiresAt { get; set; }
    public DateTime? RevokedAt { get; set; }
}

public sealed class UsersDbContext(IConfiguration c)
    : DbContext(c.GetConnectionString("UsersDb")!)
{
    public DbSet<User> Users { get; set; } = null!;
    public DbSet<Role> Roles { get; set; } = null!;
    public DbSet<RefreshToken> RefreshTokens { get; set; } = null!;

    protected override void OnModelCreating(DbModelBuilder b)
    {
        b.Entity<User>().ToTable("Users");
        b.Entity<Role>().ToTable("Roles");
        b.Entity<RefreshToken>().ToTable("RefreshTokens");

        b.Entity<User>()
            .HasRequired(x => x.Role)
            .WithMany()
            .HasForeignKey(x => x.RoleId);
    }
}

public sealed class AuthService(
    UsersDbContext db,
    JwtTokenService jwt
)
{
    public TokenResponse Signup(SignupRequest r)
    {
        if (!AuthenticationRules.IsValidSignup(r))
            throw new ArgumentException("Inputs are not valid");

        if (
            db.Users.Any(
                x => x.Email.ToLower() == r.Email.ToLower()
            )
        )
            throw new InvalidOperationException("Duplicate email");

        var roleName =
            string.IsNullOrWhiteSpace(r.Role)
                ? Roles.Doctor
                : r.Role.ToUpperInvariant();

        var role =
            db.Roles.SingleOrDefault(
                x => x.RoleName == roleName
            )
            ?? throw new ArgumentException(
                "Role is not configured"
            );

        var user = new User
        {
            Name = r.Name,
            Email = r.Email,
            PasswordHash =
                BCrypt.Net.BCrypt.HashPassword(r.Password),
            RoleId = role.Id,
            CreatedAt = DateTime.UtcNow
        };

        db.Users.Add(user);
        db.SaveChanges();

        return Issue(user, roleName);
    }

    public TokenResponse Login(LoginRequest r)
    {
        var u =
            db.Users
                .Include(x => x.Role)
                .SingleOrDefault(
                    x => x.Email == r.Email
                );

        if (
            u is null ||
            !BCrypt.Net.BCrypt.Verify(
                r.Password,
                u.PasswordHash
            )
        )
            throw new UnauthorizedAccessException();

        return Issue(u, u.Role!.RoleName);
    }

    public TokenResponse Refresh(string raw)
    {
        var tokenHash = Hash(raw);

        var token =
            db.RefreshTokens.SingleOrDefault(
                x => x.TokenHash == tokenHash
            );

        if (
            token is null ||
            !AuthenticationRules.IsRefreshTokenActive(
                token.ExpiresAt,
                token.RevokedAt,
                DateTime.UtcNow
            )
        )
            throw new UnauthorizedAccessException();

        token.RevokedAt = DateTime.UtcNow;

        var u =
            db.Users
                .Include(x => x.Role)
                .Single(x => x.Id == token.UserId);

        db.SaveChanges();

        return Issue(u, u.Role!.RoleName);
    }

    public void Logout(int userId, string raw)
    {
        var tokenHash = Hash(raw);

        var token =
            db.RefreshTokens.SingleOrDefault(
                x =>
                    x.UserId == userId &&
                    x.TokenHash == tokenHash
            );

        if (token is null)
            throw new UnauthorizedAccessException();

        token.RevokedAt = DateTime.UtcNow;
        db.SaveChanges();
    }

    private TokenResponse Issue(
        User u,
        string role
    )
    {
        var raw =
            Convert.ToBase64String(
                RandomNumberGenerator.GetBytes(64)
            );

        db.RefreshTokens.Add(
            new RefreshToken
            {
                UserId = u.Id,
                TokenHash = Hash(raw),
                IssuedAt = DateTime.UtcNow,
                ExpiresAt = DateTime.UtcNow.AddDays(7)
            }
        );

        db.SaveChanges();

        return new TokenResponse
        {
            UserId = u.Id,
            Role = role,
            AccessToken = jwt.Create(
                u.Id,
                role,
                u.Name,
                u.Email
            ),
            RefreshToken = raw
        };
    }

    private static string Hash(string s) =>
        Convert.ToBase64String(
            SHA256.HashData(
                Encoding.UTF8.GetBytes(s)
            )
        );
}