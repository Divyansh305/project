using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PharmacyEvaluation.Shared;

namespace PharmacyEvaluation.SupplierInventoryService.Controllers;

[ApiController, Authorize(Roles = Roles.Admin + "," + Roles.Doctor), Route("api/drugs")]
public sealed class DrugsController(InventoryDbContext db) : ControllerBase
{
    static DrugResponseDto Map(Drug x) => new()
    {
        DrugId = x.Id,
        Name = x.Name,
        Price = x.Price,
        QuantityInStock = x.QuantityInStock,
        IsActive = x.IsActive,
        SupplierId = x.SupplierId
    };

    [HttpGet]
    public ActionResult<IEnumerable<DrugResponseDto>> Get(bool includeInactive = false)
    {
        if (includeInactive && !User.IsInRole(Roles.Admin))
            return Forbid();

        var drugs = includeInactive
            ? db.Drugs
            : db.Drugs.Where(x => x.IsActive);

        return Ok(drugs.ToList().Select(Map));
    }

    [HttpGet("{id:int}")]
    public ActionResult<DrugResponseDto> Get(int id)
    {
        var d = db.Drugs.Find(id);

        if (d is not null &&
            !d.IsActive &&
            !User.IsInRole(Roles.Admin))
            return NotFound();

        return d is null ? NotFound() : Ok(Map(d));
    }

    [Authorize(Roles = Roles.Admin), HttpPost]
    public ActionResult<DrugResponseDto> Post([FromBody] DrugDto d)
    {
        if (d.Price < 0 || d.QuantityInStock < 0)
            return BadRequest(new ApiError { Message = "Inputs are not valid" });

        var entity = new Drug
        {
            Name = d.Name,
            Price = d.Price,
            QuantityInStock = d.QuantityInStock,
            IsActive = d.IsActive,
            SupplierId = d.SupplierId
        };

        db.Drugs.Add(entity);
        db.SaveChanges();

        return Created("", Map(entity));
    }

    [Authorize(Roles = Roles.Admin), HttpPut("{id:int}")]
    public ActionResult<DrugResponseDto> Put(int id, [FromBody] DrugDto value)
    {
        var d = db.Drugs.Find(id);

        if (d is null)
            return NotFound();

        d.Name = value.Name;
        d.Price = value.Price;
        d.QuantityInStock = value.QuantityInStock;
        d.IsActive = value.IsActive;
        d.SupplierId = value.SupplierId;

        db.SaveChanges();

        return Ok(Map(d));
    }

    [Authorize(Roles = Roles.Admin), HttpDelete("{id:int}")]
    public IActionResult Delete(int id)
    {
        var d = db.Drugs.Find(id);

        if (d is null)
            return NotFound();

        d.IsActive = false;
        db.SaveChanges();

        return Ok();
    }
}

[ApiController, Authorize(Roles = Roles.Admin), Route("api/suppliers")]
public sealed class SuppliersController(InventoryDbContext db) : ControllerBase
{
    [HttpGet]
    public IActionResult Get()
        => Ok(db.Suppliers.ToList());

    [HttpPost]
    public IActionResult Post([FromBody] SupplierDto dto)
    {
        var s = new Supplier
        {
            Name = dto.Name,
            ContactInfo = dto.ContactInfo,
            Address = dto.Address
        };

        db.Suppliers.Add(s);
        db.SaveChanges();

        return Created("", s);
    }

    [HttpPut("{id:int}")]
    public IActionResult Put(int id, [FromBody] SupplierDto dto)
    {
        var s = db.Suppliers.Find(id);

        if (s is null)
            return NotFound();

        s.Name = dto.Name;
        s.ContactInfo = dto.ContactInfo;
        s.Address = dto.Address;

        db.SaveChanges();

        return Ok(s);
    }

    [HttpDelete("{id:int}")]
    public IActionResult Delete(int id)
    {
        var s = db.Suppliers.Find(id);

        if (s is null)
            return NotFound();

        if (db.Drugs.Any(x => x.SupplierId == id))
            return Conflict();

        db.Suppliers.Remove(s);
        db.SaveChanges();

        return Ok();
    }
}

[ApiController, Route("internal/inventory")]
public sealed class InternalInventoryController(
    InventoryService service,
    IConfiguration c) : ControllerBase
{
    bool Valid()
        => Request.Headers["X-Pharmacy-Service-Key"] == c["InternalServiceAuthKey"];

    [HttpPost("reserve")]
    public IActionResult Reserve([FromBody] List<InventoryReservationItem> items)
    {
        if (!Valid())
            return Unauthorized();

        try
        {
            return Ok(service.Reserve(items));
        }
        catch (InvalidOperationException e)
        {
            return Conflict(new ApiError { Message = e.Message });
        }
    }

    [HttpPost("restore")]
    public IActionResult Restore([FromBody] List<InventoryReservationItem> items)
    {
        if (!Valid())
            return Unauthorized();

        service.Restore(items);

        return Ok();
    }

    [HttpPost("complete")]
    public IActionResult Complete([FromBody] CompleteOrderRequest r)
    {
        if (!Valid())
            return Unauthorized();

        service.Complete(r.OrderId, r.Amount);

        return Ok();
    }
}

[ApiController, Authorize(Roles = Roles.Admin), Route("api/reports/sales")]
public sealed class SalesReportsController(InventoryDbContext db) : ControllerBase
{
    [HttpGet]
    public IActionResult Get(DateTime? from = null, DateTime? to = null)
    {
        var q = db.Sales.AsQueryable();

        if (from.HasValue)
            q = q.Where(x => x.SaleDate >= from.Value);

        if (to.HasValue)
            q = q.Where(x => x.SaleDate <= to.Value);

        return Ok(
            q.OrderByDescending(x => x.SaleDate)
             .ToList());
    }

    [HttpGet("download")]
    public IActionResult Download(DateTime? from = null, DateTime? to = null)
    {
        var q = db.Sales.AsQueryable();

        if (from.HasValue)
            q = q.Where(x => x.SaleDate >= from.Value);

        if (to.HasValue)
            q = q.Where(x => x.SaleDate <= to.Value);

        var csv =
            "OrderId,Amount,SaleDate\r\n" +
            string.Join(
                "\r\n",
                q.OrderByDescending(x => x.SaleDate)
                 .ToList()
                 .Select(x =>
                     $"{x.OrderId},{x.Amount},{x.SaleDate:O}"));

        return File(
            System.Text.Encoding.UTF8.GetBytes(csv),
            "text/csv",
            "sales-report.csv");
    }

    [HttpGet("print")]
    public IActionResult Print()
        => Content(
            "<html><body><h1>Sales Report</h1></body></html>",
            "text/html");
}