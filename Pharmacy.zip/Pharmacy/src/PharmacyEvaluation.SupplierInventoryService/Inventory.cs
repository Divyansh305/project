using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity;
using PharmacyEvaluation.Shared;

namespace PharmacyEvaluation.SupplierInventoryService;

public sealed class Supplier
{
    [Key, Column("SupplierId")]
    public int Id { get; set; }

    public string Name { get; set; } = "";
    public string ContactInfo { get; set; } = "";
    public string? Address { get; set; }
}

public sealed class Drug
{
    [Key, Column("DrugId")]
    public int Id { get; set; }

    public string Name { get; set; } = "";
    public decimal Price { get; set; }
    public int QuantityInStock { get; set; }
    public bool IsActive { get; set; }
    public int SupplierId { get; set; }
}

public sealed class Sale
{
    [Key, Column("SaleId")]
    public int Id { get; set; }

    public int OrderId { get; set; }
    public decimal Amount { get; set; }
    public DateTime SaleDate { get; set; }
}

public sealed class ProcessedEvent
{
    [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
    public int OrderId { get; set; }

    public DateTime ProcessedAt { get; set; }
}

public class DrugDto
{
    public string Name { get; set; } = "";
    public decimal Price { get; set; }
    public int QuantityInStock { get; set; }
    public bool IsActive { get; set; }
    public int SupplierId { get; set; }
}

public sealed class DrugResponseDto : DrugDto
{
    public int DrugId { get; set; }
}

public sealed class SupplierDto
{
    public string Name { get; set; } = "";
    public string ContactInfo { get; set; } = "";
    public string? Address { get; set; }
}

public sealed class CompleteOrderRequest
{
    public int OrderId { get; set; }
    public decimal Amount { get; set; }
}

public sealed class InventoryDbContext(IConfiguration c)
    : DbContext(c.GetConnectionString("InventoryDb")!)
{
    public DbSet<Supplier> Suppliers { get; set; } = null!;
    public DbSet<Drug> Drugs { get; set; } = null!;
    public DbSet<Sale> Sales { get; set; } = null!;
    public DbSet<ProcessedEvent> ProcessedEvents { get; set; } = null!;

    protected override void OnModelCreating(DbModelBuilder b)
    {
        b.Entity<Supplier>().ToTable("Suppliers");
        b.Entity<Drug>().ToTable("Drugs");
        b.Entity<Sale>().ToTable("Sales");
        b.Entity<ProcessedEvent>().ToTable("ProcessedEvents");
    }
}

public sealed class InventoryService(InventoryDbContext db)
{
    public List<ReservedDrug> Reserve(
        List<InventoryReservationItem> items
    )
    {
        if (items is null || items.Count == 0)
            throw new ArgumentException("Inputs are not valid");

        using var tx = db.Database.BeginTransaction(
            IsolationLevel.Serializable
        );

        var result = new List<ReservedDrug>();

        foreach (var grouped in items.GroupBy(x => x.DrugId))
        {
            var d = db.Drugs.SingleOrDefault(
                x => x.Id == grouped.Key
            );

            var q = grouped.Sum(x => x.Quantity);

            if (
                d is null ||
                !InventoryRules.CanReserve(
                    d.QuantityInStock,
                    q,
                    d.IsActive
                )
            )
                throw new InvalidOperationException(
                    "Insufficient stock"
                );

            var changed = db.Database.ExecuteSqlCommand(
                "UPDATE Drugs SET QuantityInStock = QuantityInStock - @p0 WHERE DrugId = @p1 AND QuantityInStock >= @p0 AND IsActive = 1",
                q,
                d.Id
            );

            if (changed != 1)
                throw new InvalidOperationException(
                    "Insufficient stock"
                );

            result.Add(
                new ReservedDrug
                {
                    DrugId = d.Id,
                    Name = d.Name,
                    Price = d.Price,
                    Quantity = q
                }
            );
        }

        tx.Commit();

        return result;
    }

    public void Restore(
        IEnumerable<InventoryReservationItem> items
    )
    {
        foreach (var x in items)
        {
            db.Database.ExecuteSqlCommand(
                "UPDATE Drugs SET QuantityInStock = QuantityInStock + @p0 WHERE DrugId = @p1",
                x.Quantity,
                x.DrugId
            );
        }
    }

    public void Complete(
        int orderId,
        decimal amount
    )
    {
        if (
            db.ProcessedEvents.Any(
                x => x.OrderId == orderId
            )
        )
            return;

        db.Sales.Add(
            new Sale
            {
                OrderId = orderId,
                Amount = amount,
                SaleDate = DateTime.UtcNow
            }
        );

        db.ProcessedEvents.Add(
            new ProcessedEvent
            {
                OrderId = orderId,
                ProcessedAt = DateTime.UtcNow
            }
        );

        db.SaveChanges();
    }
}