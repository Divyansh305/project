using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using PharmacyEvaluation.OrderService;
using PharmacyEvaluation.Shared;

var builder = WebApplication.CreateBuilder(
    new WebApplicationOptions
    {
        Args = args,
        ContentRootPath = AppContext.BaseDirectory
    }
);

builder.WebHost.UseUrls(
    builder.Configuration["SelfHost:Url"] ?? "http://localhost:51951"
);

builder.Services.Configure<JwtOptions>(
    builder.Configuration.GetSection("Jwt")
);

builder.Services.AddSingleton<JwtTokenService>();
builder.Services.AddScoped<OrdersDbContext>();
builder.Services.AddScoped<OrderWorkflow>();
builder.Services.AddSingleton<SmtpNotifier>();
builder.Services.AddHttpClient("inventory");
builder.Services.AddHttpClient("razorpay");
builder.Services.AddSingleton<IPaymentGateway>(sp =>
    PaymentGatewayFactory.Create(
        builder.Configuration,
        sp.GetRequiredService<IHttpClientFactory>()
    )
);
builder.Services.AddControllers();

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        var jwt = builder.Configuration.GetSection("Jwt").Get<JwtOptions>()!;

        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt.Issuer,
            ValidateAudience = true,
            ValidAudience = jwt.Audience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(jwt.Secret)
            ),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddAuthorization();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UsePharmacyExceptionHandling();
app.UseSwagger();
app.UseSwaggerUI();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();

public partial class Program
{
}