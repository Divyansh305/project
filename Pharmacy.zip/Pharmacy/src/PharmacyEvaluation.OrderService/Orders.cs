using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Net.Http.Json;
using System.Net.Mail;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using PharmacyEvaluation.Shared;

namespace PharmacyEvaluation.OrderService;

public class Order
{
    [Key, Column("OrderId")]
    public int Id { get; set; }

    public int DoctorId { get; set; }

    public string DoctorNameSnapshot { get; set; } = "";

    public string? DoctorEmailSnapshot { get; set; }

    public string Status { get; set; } = "NEW";

    public decimal TotalAmount { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? VerifiedAt { get; set; }

    public DateTime? PickedUpAt { get; set; }

    public DateTime? CompletedAt { get; set; }

    public DateTime? CancelledAt { get; set; }

    public virtual ICollection<OrderItem> Items { get; set; } = [];
}

public sealed class OrderItem
{
    [Key, Column("OrderItemId")]
    public int Id { get; set; }

    public int OrderId { get; set; }

    public int DrugId { get; set; }

    public int Quantity { get; set; }

    public decimal UnitPriceAtOrder { get; set; }
}

public sealed class Payment
{
    [Key, Column("PaymentId")]
    public int Id { get; set; }

    public int OrderId { get; set; }

    public decimal Amount { get; set; }

    public string Status { get; set; } = "PENDING";

    public string? TransactionReference { get; set; }

    public DateTime CreatedAt { get; set; }
}

public sealed class OrdersDbContext(IConfiguration c)
    : DbContext(c.GetConnectionString("OrdersDb")!)
{
    public DbSet<Order> Orders { get; set; } = null!;

    public DbSet<OrderItem> OrderItems { get; set; } = null!;

    public DbSet<Payment> Payments { get; set; } = null!;

    protected override void OnModelCreating(DbModelBuilder b)
    {
        b.Entity<Order>().ToTable("Orders");
        b.Entity<OrderItem>().ToTable("OrderItems");
        b.Entity<Payment>().ToTable("Payments");

        b.Entity<Order>()
            .HasMany(x => x.Items)
            .WithRequired()
            .HasForeignKey(x => x.OrderId);
    }
}

public interface IPaymentGateway
{
    PaymentResult Charge(int orderId, decimal amount);

    bool Refund(string? reference, decimal amount);
}

public interface IPaymentCheckoutGateway
{
    Task<RazorpayCheckoutResponse> CreateOrder(
        int pharmacyOrderId,
        decimal amount);

    bool Verify(
        string orderId,
        string paymentId,
        string signature);
}

public sealed class DummyPaymentGateway : IPaymentGateway
{
    public PaymentResult Charge(int id, decimal amount)
    {
        return new PaymentResult
        {
            Succeeded = true,
            TransactionReference = "dummy-order-" + id
        };
    }

    public bool Refund(string? reference, decimal amount)
    {
        return !string.IsNullOrWhiteSpace(reference);
    }

}

public sealed class RazorpayPaymentGateway(
    IConfiguration c,
    IHttpClientFactory clients) : IPaymentGateway, IPaymentCheckoutGateway
{
    private string KeyId =>
        c["Razorpay:KeyId"]
        ?? "";

    private string KeySecret =>
        c["Razorpay:KeySecret"]
        ?? "";

    private void ValidateConfiguration()
    {
        if (!string.Equals(c["Razorpay:Mode"], "TEST", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException(
                "Only Razorpay Test Mode is permitted");

        if (string.IsNullOrWhiteSpace(KeyId) ||
            string.IsNullOrWhiteSpace(KeySecret))
            throw new InvalidOperationException(
                "Razorpay Test Mode credentials are not configured");
    }

    public PaymentResult Charge(int id, decimal amount)
    {
        throw new InvalidOperationException(
            "Razorpay payments require checkout verification");
    }

    public bool Refund(string? reference, decimal amount)
    {
        ValidateConfiguration();
        if (string.IsNullOrWhiteSpace(reference))
            return false;

        var client = clients.CreateClient("razorpay");
        var auth = Convert.ToBase64String(Encoding.UTF8.GetBytes(KeyId + ":" + KeySecret));
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Basic", auth);
        var response = client.PostAsJsonAsync(
            $"https://api.razorpay.com/v1/payments/{reference}/refund",
            new { amount = checked((int)decimal.Round(amount * 100m, 0, MidpointRounding.AwayFromZero)) })
            .GetAwaiter()
            .GetResult();
        return response.IsSuccessStatusCode;
    }

    public async Task<RazorpayCheckoutResponse> CreateOrder(
        int pharmacyOrderId,
        decimal amount)
    {
        ValidateConfiguration();

        var client = clients.CreateClient("razorpay");
        var auth = Convert.ToBase64String(
            Encoding.UTF8.GetBytes(KeyId + ":" + KeySecret));

        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Basic", auth);

        var response = await client.PostAsJsonAsync(
            "https://api.razorpay.com/v1/orders",
            new
            {
                amount = checked((int)decimal.Round(
                    amount * 100m,
                    0,
                    MidpointRounding.AwayFromZero)),
                currency = "INR",
                receipt = "pharmacy-" + pharmacyOrderId
            });

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(
                "Razorpay order creation failed");

        using var document = JsonDocument.Parse(
            await response.Content.ReadAsStringAsync());

        var root = document.RootElement;

        return new RazorpayCheckoutResponse
        {
            KeyId = KeyId,
            OrderId = root.GetProperty("id").GetString() ?? "",
            Amount = root.GetProperty("amount").GetInt32(),
            Currency = root.GetProperty("currency").GetString() ?? "INR"
        };
    }

    public bool Verify(
        string orderId,
        string paymentId,
        string signature)
    {
        ValidateConfiguration();

        using var hmac = new HMACSHA256(
            Encoding.UTF8.GetBytes(KeySecret));

        var digest = Convert.ToHexString(
            hmac.ComputeHash(
                Encoding.UTF8.GetBytes(orderId + "|" + paymentId)))
            .ToLowerInvariant();

        return CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(digest),
            Encoding.UTF8.GetBytes(signature));
    }
}

public static class PaymentGatewayFactory
{
    public static IPaymentGateway Create(IConfiguration c)
    {
        return (c["Payment:Gateway"] ?? "DUMMY")
            .ToUpperInvariant() switch
        {
            "DUMMY" => new DummyPaymentGateway(),
            "RAZORPAY" => throw new InvalidOperationException(
                "Razorpay requires the HTTP client factory overload"),
            _ => throw new InvalidOperationException(
                "PAYMENT_GATEWAY must be DUMMY or RAZORPAY")
        };
    }

    public static IPaymentGateway Create(
        IConfiguration c,
        IHttpClientFactory clients)
    {
        return (c["Payment:Gateway"] ?? "DUMMY")
            .ToUpperInvariant() switch
        {
            "DUMMY" => new DummyPaymentGateway(),

            "RAZORPAY" => new RazorpayPaymentGateway(c, clients),

            _ => throw new InvalidOperationException(
                "PAYMENT_GATEWAY must be DUMMY or RAZORPAY")
        };
    }
}

public sealed class SmtpNotifier(IConfiguration c)
{
    public bool Send(string to, string subject, string body)
    {
        var host = c["Smtp:Host"];
        var from = c["Smtp:From"];

        if (string.IsNullOrWhiteSpace(host) ||
            string.IsNullOrWhiteSpace(from) ||
            string.IsNullOrWhiteSpace(to))
        {
            System.Diagnostics.Trace.TraceWarning(
                "SMTP notification skipped because recipient or SMTP configuration is missing");
            return false;
        }

        try
        {
            using var client = new SmtpClient(
                host,
                int.Parse(c["Smtp:Port"] ?? "587"))
            {
                EnableSsl = bool.Parse(
                    c["Smtp:EnableSsl"] ?? "true"),

                Credentials = new System.Net.NetworkCredential(
                    c["Smtp:Username"],
                    c["Smtp:Password"])
            };

            client.Send(from, to, subject, body);
            return true;
        }
        catch (SmtpException exception)
        {
            System.Diagnostics.Trace.TraceError(
                "SMTP notification failed for order email recipient: " + exception.Message);
            return false;
        }
        catch (FormatException exception)
        {
            System.Diagnostics.Trace.TraceError(
                "SMTP notification configuration is invalid: " + exception.Message);
            return false;
        }
        catch (InvalidOperationException exception)
        {
            System.Diagnostics.Trace.TraceError(
                "SMTP notification could not be sent: " + exception.Message);
            return false;
        }
    }
}

public static class OrderEmailTemplates
{
    public static string Created(Order order, Payment? payment) =>
        Header($"Order #{order.Id} created") +
        $"Your pharmacy order has been created successfully.\n\n{OrderSummary(order)}" +
        PaymentSummary(payment);

    public static string PaymentSuccess(Order order, Payment payment) =>
        Header($"Payment confirmed for order #{order.Id}") +
        $"Your payment has been successfully received.\n\n{OrderSummary(order)}" +
        $"\nPayment status: {payment.Status}\nTransaction reference: {payment.TransactionReference}\nPayment date: {payment.CreatedAt:u}";

    public static string PaymentFailed(Order order, Payment payment) =>
        Header($"Payment failed for order #{order.Id}") +
        $"Payment could not be completed. Please try payment again if the order is still available.\n\n" +
        $"Order ID: {order.Id}\nAmount: {payment.Amount:C}\nPayment status: {payment.Status}";

    public static string Verified(Order order) =>
        Header($"Order #{order.Id} verified") +
        $"Your order has been verified by the pharmacy administrator.\n\n{OrderSummary(order)}\nVerified date: {order.VerifiedAt:u}";

    public static string Completed(Order order) =>
        Header($"Order #{order.Id} completed") +
        $"Your order has been completed/picked up successfully.\n\n{OrderSummary(order)}\nCompletion date: {order.CompletedAt:u}";

    public static string Cancelled(Order order) =>
        Header($"Order #{order.Id} cancelled") +
        $"Your order has been cancelled by the pharmacy administrator.\n\n{OrderSummary(order)}\nCancellation date: {order.CancelledAt:u}";

    private static string Header(string title) =>
        $"PharmaCare\nPharmacy Management System\n{title}\n\n";

    private static string OrderSummary(Order order) =>
        $"Doctor: {order.DoctorNameSnapshot}\nOrder ID: {order.Id}\nOrder date: {order.CreatedAt:u}\n" +
        $"Status: {order.Status}\nTotal amount: {order.TotalAmount:C}\n" +
        string.Join("\n", order.Items.Select(x =>
            $"Drug #{x.DrugId}: {x.Quantity} x {x.UnitPriceAtOrder:C}"));

    private static string PaymentSummary(Payment? payment) =>
        payment is null
            ? ""
            : $"\n\nPayment status: {payment.Status}\nTransaction reference: {payment.TransactionReference}";
}

public sealed class OrderWorkflow(
    OrdersDbContext db,
    IPaymentGateway payment,
    IHttpClientFactory clients,
    IConfiguration c,
    SmtpNotifier mail)
{
    public async Task<Order> Create(
        int doctorId,
        string name,
        string? email,
        CreateOrderRequest r)
    {
        if (!OrderRules.IsValidNewOrder(r))
        {
            throw new ArgumentException(
                "Inputs are not valid");
        }

        var reserved = await Call<List<ReservedDrug>>(
            "/internal/inventory/reserve",
            r.Items.Select(x =>
                new InventoryReservationItem
                {
                    DrugId = x.DrugId,
                    Quantity = x.Quantity
                }).ToList())
            ?? throw new InvalidOperationException(
                "Inventory service returned no reservation");

        var order = new Order
        {
            DoctorId = doctorId,
            DoctorNameSnapshot = name,
            DoctorEmailSnapshot = email,
            CreatedAt = DateTime.UtcNow,

            Items = reserved.Select(x =>
                new OrderItem
                {
                    DrugId = x.DrugId,
                    Quantity = x.Quantity,
                    UnitPriceAtOrder = x.Price
                }).ToList()
        };

        order.TotalAmount = order.Items.Sum(
            x => x.Quantity * x.UnitPriceAtOrder);

        db.Orders.Add(order);
        db.SaveChanges();

        if (payment is IPaymentCheckoutGateway)
        {
            db.Payments.Add(
                new Payment
                {
                    OrderId = order.Id,
                    Amount = order.TotalAmount,
                    Status = "PENDING",
                    CreatedAt = DateTime.UtcNow
                });

            db.SaveChanges();
            Notify(
                order,
                "Pharmacy Order Created - Order #" + order.Id,
                OrderEmailTemplates.Created(order, db.Payments.Single(x => x.OrderId == order.Id)));
            return order;
        }

        var result = payment.Charge(order.Id, order.TotalAmount);

        db.Payments.Add(
            new Payment
            {
                OrderId = order.Id,
                Amount = order.TotalAmount,
                Status = result.Succeeded
                    ? "SUCCESS"
                    : "FAILED",

                TransactionReference =
                    result.TransactionReference,

                CreatedAt = DateTime.UtcNow
            });

        if (!result.Succeeded)
        {
            order.Status = "CANCELLED";

            await Call<object>(
                "/internal/inventory/restore",
                r.Items);
        }

        db.SaveChanges();

        if (result.Succeeded)
        {
            var record = db.Payments.Single(x => x.OrderId == order.Id);
            Notify(order, "Pharmacy Order Created - Order #" + order.Id, OrderEmailTemplates.Created(order, record));
            Notify(order, "Payment Confirmation - Order #" + order.Id, OrderEmailTemplates.PaymentSuccess(order, record));
        }
        else
        {
            Notify(order, "Payment Failed - Order #" + order.Id, OrderEmailTemplates.PaymentFailed(order, db.Payments.Single(x => x.OrderId == order.Id)));
        }

        return order;
    }

    public async Task<RazorpayCheckoutResponse> CreatePaymentOrder(
        int orderId,
        int doctorId)
    {
        var order = Get(orderId);

        if (order.DoctorId != doctorId)
            throw new UnauthorizedAccessException();

        var checkout = payment as IPaymentCheckoutGateway
            ?? throw new InvalidOperationException(
                "Razorpay checkout is not enabled");

        var record = db.Payments.SingleOrDefault(
            x => x.OrderId == orderId)
            ?? throw new InvalidOperationException(
                "Payment record was not found");

        if (record.Status == "SUCCESS")
            throw new InvalidOperationException(
                "Order payment is already complete");

        return await checkout.CreateOrder(orderId, order.TotalAmount);
    }

    public async Task<PaymentVerificationResponse> VerifyPayment(
        int orderId,
        int doctorId,
        RazorpayVerificationRequest request)
    {
        var order = Get(orderId);

        if (order.DoctorId != doctorId)
            throw new UnauthorizedAccessException();

        var checkout = payment as IPaymentCheckoutGateway
            ?? throw new InvalidOperationException(
                "Razorpay checkout is not enabled");

        var record = db.Payments.SingleOrDefault(
            x => x.OrderId == orderId)
            ?? throw new KeyNotFoundException();

        if (record.Status == "SUCCESS")
            return new PaymentVerificationResponse
            {
                Succeeded = true,
                TransactionReference = record.TransactionReference
            };

        if (string.IsNullOrWhiteSpace(request.RazorpayOrderId) ||
            string.IsNullOrWhiteSpace(request.RazorpayPaymentId) ||
            string.IsNullOrWhiteSpace(request.RazorpaySignature) ||
            !checkout.Verify(
                request.RazorpayOrderId,
                request.RazorpayPaymentId,
                request.RazorpaySignature))
        {
            record.Status = "FAILED";
            await FailPayment(orderId);
            throw new UnauthorizedAccessException(
                "Razorpay payment verification failed");
        }

        record.Status = "SUCCESS";
        record.TransactionReference = request.RazorpayPaymentId;
        db.SaveChanges();

        Notify(order, "Payment Confirmation - Order #" + order.Id, OrderEmailTemplates.PaymentSuccess(order, record));

        return new PaymentVerificationResponse
        {
            Succeeded = true,
            TransactionReference = record.TransactionReference
        };
    }

    public async Task FailPayment(
        int orderId,
        int doctorId)
    {
        var order = Get(orderId);

        if (order.DoctorId != doctorId)
            throw new UnauthorizedAccessException();

        await FailPayment(orderId);
    }

    private async Task FailPayment(int orderId)
    {
        var record = db.Payments.SingleOrDefault(
            x => x.OrderId == orderId);

        var order = Get(orderId);

        if (record is null || record.Status == "SUCCESS")
            return;

        record.Status = "FAILED";

        if (order.Status == "NEW")
        {
            await Call<object>(
                "/internal/inventory/restore",
                order.Items.Select(x =>
                    new InventoryReservationItem
                    {
                        DrugId = x.DrugId,
                        Quantity = x.Quantity
                    }).ToList());

            order.Status = "CANCELLED";
            order.CancelledAt = DateTime.UtcNow;
        }

        db.SaveChanges();
        Notify(order, "Payment Failed - Order #" + order.Id, OrderEmailTemplates.PaymentFailed(order, record));
    }

    public Order Get(int id)
    {
        return db.Orders
            .Include(x => x.Items)
            .SingleOrDefault(x => x.Id == id)
            ?? throw new KeyNotFoundException();
    }

    public Order Verify(int id)
    {
        var o = Get(id);

        var paymentRecord = db.Payments.SingleOrDefault(
            x => x.OrderId == id);

        if (paymentRecord?.Status != "SUCCESS")
            throw new ArgumentException(
                "Payment must be completed before verification");

        if (!OrderRules.CanVerify(o.Status))
        {
            throw new ArgumentException(
                "Invalid order state");
        }

        o.Status = "VERIFIED";
        o.VerifiedAt = DateTime.UtcNow;

        db.SaveChanges();
        Notify(o, "Order Verified - Order #" + o.Id, OrderEmailTemplates.Verified(o));

        return o;
    }

    public async Task<Order> Pickup(int id)
    {
        var o = Get(id);

        if (!OrderRules.CanPickUp(o.Status))
        {
            throw new ArgumentException(
                "Invalid order state");
        }

        o.Status = "PICKED_UP";
        o.PickedUpAt = DateTime.UtcNow;

        db.SaveChanges();

        await Call<object>(
            "/internal/inventory/complete",
            new
            {
                OrderId = o.Id,
                Amount = o.TotalAmount
            });

        o.Status = "COMPLETED";
        o.CompletedAt = DateTime.UtcNow;

        db.SaveChanges();
        Notify(o, "Order Completed - Order #" + o.Id, OrderEmailTemplates.Completed(o));

        return o;
    }

    public async Task<Order> Cancel(int id)
    {
        var o = Get(id);

        if (!OrderRules.CanCancel(o.Status))
        {
            throw new ArgumentException(
                "Invalid order state");
        }

        var paymentRecord = db.Payments.SingleOrDefault(x => x.OrderId == id);
        if (paymentRecord?.Status == "SUCCESS")
        {
            if (!payment.Refund(paymentRecord.TransactionReference, paymentRecord.Amount))
                throw new InvalidOperationException("Payment refund failed; order was not cancelled");
            paymentRecord.Status = "REFUNDED";
        }

        await Call<object>(
            "/internal/inventory/restore",
            o.Items.Select(x =>
                new InventoryReservationItem
                {
                    DrugId = x.DrugId,
                    Quantity = x.Quantity
                }).ToList());

        o.Status = "CANCELLED";
        o.CancelledAt = DateTime.UtcNow;

        db.SaveChanges();
        Notify(o, "Order Cancelled - Order #" + o.Id, OrderEmailTemplates.Cancelled(o));

        return o;
    }

    private void Notify(Order order, string subject, string body)
    {
        if (!string.IsNullOrWhiteSpace(order.DoctorEmailSnapshot))
            mail.Send(order.DoctorEmailSnapshot, subject, body);

        var adminEmail = c["Smtp:AdminEmail"];
        if (!string.IsNullOrWhiteSpace(adminEmail) &&
            !string.Equals(
                adminEmail,
                order.DoctorEmailSnapshot,
                StringComparison.OrdinalIgnoreCase))
        {
            mail.Send(adminEmail, subject, body);
        }
    }

    private async Task<T?> Call<T>(
        string path,
        object body)
    {
        var client =
            clients.CreateClient("inventory");

        client.BaseAddress =
            new Uri(c["Services:InventoryUrl"]!);

        client.DefaultRequestHeaders.Add(
            "X-Pharmacy-Service-Key",
            c["InternalServiceAuthKey"]);

        var response =
            await client.PostAsJsonAsync(path, body);

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(
                "Inventory service request failed");
        }

        if (response.Content.Headers.ContentLength == 0 ||
            typeof(T) == typeof(object))
        {
            return default;
        }

        return await response.Content
            .ReadFromJsonAsync<T>();
    }
}