using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PharmacyEvaluation.Shared;

namespace PharmacyEvaluation.OrderService.Controllers;

[ApiController, Authorize, Route("api/orders")]
public sealed class OrdersController(OrderWorkflow service, OrdersDbContext db) : ControllerBase
{
    [Authorize(Roles = Roles.Doctor), HttpPost]
    public async Task<ActionResult<Order>> Post([FromBody] CreateOrderRequest r)
    {
        try
        {
            return Created(
                "",
                await service.Create(
                    int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!),
                    User.Identity?.Name ?? "Doctor",
                    User.FindFirstValue(ClaimTypes.Email),
                    r
                )
            );
        }
        catch (InvalidOperationException e)
        {
            return Conflict(new ApiError { Message = e.Message });
        }
        catch (ArgumentException e)
        {
            return BadRequest(new ApiError { Message = e.Message });
        }
    }

    [Authorize(Roles = Roles.Doctor), HttpPost("{id:int}/payment/razorpay")]
    public async Task<ActionResult<RazorpayCheckoutResponse>> CreateRazorpayOrder(int id)
    {
        try
        {
            return Ok(await service.CreatePaymentOrder(
                id,
                int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!)));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (InvalidOperationException e)
        {
            return Conflict(new ApiError { Message = e.Message });
        }
    }

    [Authorize(Roles = Roles.Doctor), HttpPost("{id:int}/payment/razorpay/verify")]
    public async Task<ActionResult<PaymentVerificationResponse>> VerifyRazorpayPayment(
        int id,
        [FromBody] RazorpayVerificationRequest request)
    {
        try
        {
            return Ok(await service.VerifyPayment(
                id,
                int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!),
                request));
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized(new ApiError { Message = "Payment verification failed" });
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (InvalidOperationException e)
        {
            return Conflict(new ApiError { Message = e.Message });
        }
    }

    [Authorize(Roles = Roles.Doctor), HttpPost("{id:int}/payment/razorpay/fail")]
    public async Task<IActionResult> FailRazorpayPayment(int id)
    {
        try
        {
            await service.FailPayment(
                id,
                int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!));
            return Ok();
        }
        catch (UnauthorizedAccessException)
        {
            return Unauthorized();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpGet]
    public ActionResult<IEnumerable<Order>> Get(string? status = null)
    {
        var q = db.Orders.Include("Items").AsQueryable();

        if (!User.IsInRole(Roles.Admin))
        {
            var doctorId = int.Parse(
                User.FindFirstValue(ClaimTypes.NameIdentifier)!);

            q = q.Where(x => x.DoctorId == doctorId);
        }

        if (!string.IsNullOrWhiteSpace(status))
            q = q.Where(x => x.Status == status);

        return Ok(q.OrderByDescending(x => x.CreatedAt).ToList());
    }

    [HttpGet("{id:int}")]
    public ActionResult<Order> Get(int id)
    {
        try
        {
            var o = service.Get(id);

            return !User.IsInRole(Roles.Admin) &&
                   o.DoctorId != int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!)
                ? Forbid()
                : Ok(o);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [Authorize(Roles = Roles.Admin), HttpPut("{id:int}/verify")]
    public ActionResult<Order> Verify(int id)
    {
        try
        {
            return Ok(service.Verify(id));
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (ArgumentException e)
        {
            return BadRequest(new ApiError { Message = e.Message });
        }
    }

    [Authorize(Roles = Roles.Admin), HttpPut("{id:int}/pickup")]
    public async Task<ActionResult<Order>> Pickup(int id)
    {
        try
        {
            return Ok(await service.Pickup(id));
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (ArgumentException e)
        {
            return BadRequest(new ApiError { Message = e.Message });
        }
    }

    [Authorize(Roles = Roles.Admin + "," + Roles.Doctor), HttpPut("{id:int}/cancel")]
    public async Task<ActionResult<Order>> Cancel(int id)
    {
        try
        {
            if (User.IsInRole(Roles.Doctor))
            {
                var order = service.Get(id);
                if (order.DoctorId != int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!))
                    return Forbid();
                if (order.Status is not ("NEW" or "VERIFIED"))
                    return BadRequest(new ApiError { Message = "Only NEW or VERIFIED orders can be cancelled" });
            }
            return Ok(await service.Cancel(id));
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
        catch (ArgumentException e)
        {
            return BadRequest(new ApiError { Message = e.Message });
        }
    }
}