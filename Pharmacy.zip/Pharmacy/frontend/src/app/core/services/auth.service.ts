import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, Observable, of, tap } from 'rxjs';
import { LoginRequest, SignupRequest, TokenResponse } from '../models/models';

const API = 'http://localhost:51946/api';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly token = signal<TokenResponse | null>(this.readToken());
  readonly session = this.token.asReadonly();
  readonly isAuthenticated = computed(() => !!this.token()?.accessToken);
  readonly role = computed(() => this.token()?.role?.toUpperCase() ?? '');
  readonly userName = computed(() => this.decodeName(this.token()?.accessToken));
  readonly userEmail = computed(() =>
    this.decodeClaim(
      this.token()?.accessToken,
      'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress',
      'email',
    ),
  );
  readonly userId = computed(() => this.token()?.userId ?? 0);

  login(request: LoginRequest) {
    return this.http.post<TokenResponse>(`${API}/auth/login`, request).pipe(
      tap((result) => {
        this.save(result);
        this.goHome();
      }),
    );
  }
  signup(request: SignupRequest) {
    return this.http.post<TokenResponse>(`${API}/auth/signup`, { ...request, role: 'DOCTOR' }).pipe(
      tap((result) => {
        this.save(result);
        this.goHome();
      }),
    );
  }
  logout() {
    const refreshToken = this.token()?.refreshToken;
    const request = refreshToken
      ? this.http.post(`${API}/auth/logout`, { refreshToken }).pipe(catchError(() => of(null)))
      : of(null);
    request.subscribe(() => {
      localStorage.removeItem('pharma.session');
      this.token.set(null);
      this.router.navigateByUrl('/login');
    });
  }
  refresh(): Observable<TokenResponse | null> {
    const refreshToken = this.token()?.refreshToken;
    return refreshToken
      ? this.http
          .post<TokenResponse>(`${API}/auth/refresh`, { refreshToken })
          .pipe(tap((r) => this.save(r)))
      : of(null);
  }
  accessToken() {
    return this.token()?.accessToken ?? null;
  }
  private save(result: TokenResponse) {
    localStorage.setItem('pharma.session', JSON.stringify(result));
    this.token.set(result);
  }
  private readToken(): TokenResponse | null {
    try {
      return JSON.parse(localStorage.getItem('pharma.session') ?? 'null');
    } catch {
      return null;
    }
  }
  private decodeName(token?: string) {
    if (!token) return '';
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return (
        payload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'] || payload.name || ''
      );
    } catch {
      return '';
    }
  }
  private decodeClaim(token: string | undefined, claim: string, fallback: string) {
    if (!token) return '';
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload[claim] || payload[fallback] || '';
    } catch {
      return '';
    }
  }
  private goHome() {
    this.router.navigateByUrl(this.role() === 'ADMIN' ? '/admin' : '/doctor');
  }
}
