import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import {
  Drug,
  DrugRequest,
  Order,
  PaymentVerificationResponse,
  RazorpayCheckoutResponse,
  RazorpayVerificationRequest,
  Sale,
  Supplier,
  SupplierRequest,
} from '../models/models';
const API = 'http://localhost:51946/api';
@Injectable({ providedIn: 'root' })
export class DrugsService {
  private http = inject(HttpClient);
  list(includeInactive = false) {
    return this.http.get<Drug[]>(`${API}/drugs`, {
      params: includeInactive ? new HttpParams().set('includeInactive', 'true') : undefined,
    });
  }
  get(id: number) {
    return this.http.get<Drug>(`${API}/drugs/${id}`);
  }
  create(data: DrugRequest) {
    return this.http.post<Drug>(`${API}/drugs`, data);
  }
  update(id: number, data: DrugRequest) {
    return this.http.put<Drug>(`${API}/drugs/${id}`, data);
  }
  remove(id: number) {
    return this.http.delete(`${API}/drugs/${id}`);
  }
}
@Injectable({ providedIn: 'root' })
export class SuppliersService {
  private http = inject(HttpClient);
  list() {
    return this.http.get<Supplier[]>(`${API}/suppliers`);
  }
  create(data: SupplierRequest) {
    return this.http.post<Supplier>(`${API}/suppliers`, data);
  }
  update(id: number, data: SupplierRequest) {
    return this.http.put<Supplier>(`${API}/suppliers/${id}`, data);
  }
  remove(id: number) {
    return this.http.delete(`${API}/suppliers/${id}`);
  }
}
@Injectable({ providedIn: 'root' })
export class OrdersService {
  private http = inject(HttpClient);
  list(status?: string) {
    return this.http.get<Order[]>(`${API}/orders`, {
      params: status ? new HttpParams().set('status', status) : undefined,
    });
  }
  get(id: number) {
    return this.http.get<Order>(`${API}/orders/${id}`);
  }
  create(items: { drugId: number; quantity: number }[]) {
    return this.http.post<Order>(`${API}/orders`, { items });
  }
  createRazorpayOrder(id: number) {
    return this.http.post<RazorpayCheckoutResponse>(`${API}/orders/${id}/payment/razorpay`, {});
  }
  verifyRazorpayPayment(id: number, request: RazorpayVerificationRequest) {
    return this.http.post<PaymentVerificationResponse>(
      `${API}/orders/${id}/payment/razorpay/verify`,
      request,
    );
  }
  failRazorpayPayment(id: number) {
    return this.http.post(`${API}/orders/${id}/payment/razorpay/fail`, {});
  }
  verify(id: number) {
    return this.http.put<Order>(`${API}/orders/${id}/verify`, {});
  }
  pickup(id: number) {
    return this.http.put<Order>(`${API}/orders/${id}/pickup`, {});
  }
  cancel(id: number) {
    return this.http.put<Order>(`${API}/orders/${id}/cancel`, {});
  }
}
@Injectable({ providedIn: 'root' })
export class ReportsService {
  private http = inject(HttpClient);
  list(from?: string, to?: string) {
    let params = new HttpParams();
    if (from) params = params.set('from', from);
    if (to) params = params.set('to', to);
    return this.http.get<Sale[]>(`${API}/reports/sales`, { params });
  }
  download() {
    return this.http.get(`${API}/reports/sales/download`, { responseType: 'blob' });
  }
  print() {
    return this.http.get(`${API}/reports/sales/print`, { responseType: 'text' });
  }
}
