import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const token = auth.accessToken();
  const request = token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;
  return next(request).pipe(
    catchError((error) => {
      if (error.status === 401 && !req.url.includes('/auth/')) {
        auth.refresh().subscribe({
          error: () => {
            localStorage.removeItem('pharma.session');
            router.navigateByUrl('/login');
          },
        });
      }
      return throwError(() => error);
    }),
  );
};
