export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
  userId: number;
  role: string;
}
export interface LoginRequest {
  email: string;
  password: string;
}
export interface SignupRequest {
  name: string;
  email: string;
  password: string;
  role?: string;
}
export interface Drug {
  drugId: number;
  name: string;
  price: number;
  quantityInStock: number;
  isActive: boolean;
  supplierId: number;
}
export interface DrugRequest {
  name: string;
  price: number;
  quantityInStock: number;
  isActive: boolean;
  supplierId: number;
}
export interface Supplier {
  id: number;
  name: string;
  contactInfo: string;
  address?: string;
}
export interface SupplierRequest {
  name: string;
  contactInfo: string;
  address?: string;
}
export interface OrderItem {
  id: number;
  orderId: number;
  drugId: number;
  quantity: number;
  unitPriceAtOrder: number;
}
export interface Order {
  id: number;
  doctorId: number;
  doctorNameSnapshot: string;
  status: string;
  totalAmount: number;
  createdAt: string;
  verifiedAt?: string;
  pickedUpAt?: string;
  cancelledAt?: string;
  items: OrderItem[];
}
export interface Sale {
  id: number;
  orderId: number;
  amount: number;
  saleDate: string;
}
export interface ApiError {
  message?: string;
  errors?: string[];
}
export interface RazorpayCheckoutResponse {
  keyId: string;
  orderId: string;
  amount: number;
  currency: string;
}
export interface RazorpayVerificationRequest {
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
}
export interface PaymentVerificationResponse {
  succeeded: boolean;
  transactionReference?: string;
}
