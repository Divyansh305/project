import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Supplier } from '../../core/models/models';
import { SuppliersService } from '../../core/services/api.services';
@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `<section class="page">
    <div class="page-title">
      <div>
        <span class="eyebrow">PARTNERS</span>
        <h2>Suppliers</h2>
        <p class="muted">Keep your supplier directory up to date.</p>
      </div>
      <button class="btn primary" (click)="open()">+ Add supplier</button>
    </div>
    <div class="panel table-panel">
      <table>
        <thead>
          <tr>
            <th>Supplier</th>
            <th>Contact</th>
            <th>Address</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          @for (s of suppliers; track s.id) {
            <tr>
              <td>
                <b>{{ s.name }}</b
                ><small>Supplier #{{ s.id }}</small>
              </td>
              <td>{{ s.contactInfo }}</td>
              <td>{{ s.address || '—' }}</td>
              <td>
                <button class="text-btn" (click)="open(s)">Edit</button
                ><button class="text-btn danger-text" (click)="remove(s.id)">Delete</button>
              </td>
            </tr>
          } @empty {
            <tr>
              <td colspan="4" class="empty">No suppliers found.</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
    @if (editing) {
      <div class="modal-backdrop">
        <div class="modal">
          <button class="close" (click)="editing = null">×</button
          ><span class="eyebrow">SUPPLIER DIRECTORY</span>
          <h3>{{ editing.id ? 'Update supplier' : 'Add supplier' }}</h3>
          <form (ngSubmit)="save()">
            <label>Name<input name="name" [(ngModel)]="editing.name" required /></label
            ><label
              >Contact info<input
                name="contact"
                [(ngModel)]="editing.contactInfo"
                required /></label
            ><label>Address<input name="address" [(ngModel)]="editing.address" /></label
            ><button class="btn primary full">Save supplier</button>
          </form>
        </div>
      </div>
    }
  </section>`,
})
export class SuppliersComponent {
  private api = inject(SuppliersService);
  private cdr = inject(ChangeDetectorRef);
  suppliers: Supplier[] = [];
  editing: any = null;
  constructor() {
    this.load();
  }
  load() {
    this.api.list().subscribe({
      next: (x) => {
        this.suppliers = x;
        this.cdr.detectChanges();
      },
    });
  }
  open(s?: Supplier) {
    this.editing = s ? { ...s } : { name: '', contactInfo: '', address: '' };
  }
  save() {
    const data = {
      name: this.editing.name,
      contactInfo: this.editing.contactInfo,
      address: this.editing.address,
    };
    const call = this.editing.id ? this.api.update(this.editing.id, data) : this.api.create(data);
    call.subscribe({
      next: () => {
        this.editing = null;
        this.load();
      },
    });
  }
  remove(id: number) {
    if (confirm('Delete this supplier?')) this.api.remove(id).subscribe(() => this.load());
  }
}
