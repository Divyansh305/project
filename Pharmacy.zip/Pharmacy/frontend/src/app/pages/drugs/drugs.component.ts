import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Drug } from '../../core/models/models';
import { DrugsService } from '../../core/services/api.services';
@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `<section class="page">
    <div class="page-title">
      <div>
        <span class="eyebrow">CATALOGUE</span>
        <h2>Drug inventory</h2>
        <p class="muted">
          {{
            isAdmin
              ? 'Manage medicines, pricing, and stock levels.'
              : 'Browse currently available medicines.'
          }}
        </p>
      </div>
      @if (isAdmin) {
        <button class="btn primary" (click)="open()">+ Add drug</button>
      }
    </div>
    <div class="toolbar">
      <input [(ngModel)]="search" placeholder="⌕  Search medicines…" />
      @if (isAdmin) {
        <select [(ngModel)]="filter" (ngModelChange)="load()">
          <option value="active">Active drugs</option>
          <option value="inactive">Deactivated drugs</option>
          <option value="all">All drugs</option>
        </select>
      }
    </div>
    @if (error) {
      <div class="alert error">{{ error }}</div>
    }
    <div class="panel table-panel">
      <table>
        <thead>
          <tr>
            <th>Medicine</th>
            <th>Price</th>
            <th>In stock</th>
            <th>Supplier ID</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          @for (drug of filtered; track drug.drugId) {
            <tr>
              <td>
                <b>{{ drug.name }}</b
                ><small>Drug #{{ drug.drugId }}</small>
              </td>
              <td>₹{{ drug.price | number: '1.2-2' }}</td>
              <td>
                <span [class.low-stock]="drug.quantityInStock < 10"
                  >{{ drug.quantityInStock }} units</span
                >
              </td>
              <td>#{{ drug.supplierId }}</td>
              <td>
                <span
                  class="status"
                  [class.active]="drug.isActive"
                  [class.cancelled]="!drug.isActive"
                  >{{ drug.isActive ? 'Active' : 'Deactivated' }}</span
                >
              </td>
              <td>
                @if (isAdmin && drug.isActive) {
                  <button class="text-btn" (click)="open(drug)">Edit</button
                  ><button class="text-btn danger-text" (click)="remove(drug.drugId)">
                    Deactivate
                  </button>
                }
                @if (isAdmin && !drug.isActive) {
                  <button class="text-btn" (click)="activate(drug)">Activate</button>
                }
              </td>
            </tr>
          } @empty {
            <tr>
              <td colspan="6" class="empty">No medicines found.</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
    @if (editing) {
      <div class="modal-backdrop">
        <div class="modal">
          <button class="close" (click)="editing = null">×</button
          ><span class="eyebrow">{{ editing.drugId ? 'EDIT MEDICINE' : 'NEW MEDICINE' }}</span>
          <h3>{{ editing.drugId ? 'Update drug' : 'Add drug' }}</h3>
          <form (ngSubmit)="save()">
            <label>Name<input name="name" [(ngModel)]="editing.name" required /></label>
            <div class="form-row">
              <label
                >Price<input
                  type="number"
                  name="price"
                  [(ngModel)]="editing.price"
                  min="0"
                  required /></label
              ><label
                >Stock<input
                  type="number"
                  name="stock"
                  [(ngModel)]="editing.quantityInStock"
                  min="0"
                  required
              /></label>
            </div>
            <label
              >Supplier ID<input
                type="number"
                name="supplier"
                [(ngModel)]="editing.supplierId"
                required /></label
            ><button class="btn primary full">Save changes</button>
          </form>
        </div>
      </div>
    }
  </section>`,
})
export class DrugsComponent {
  private api = inject(DrugsService);
  private route = inject(ActivatedRoute);
  private cdr = inject(ChangeDetectorRef);
  drugs: Drug[] = [];
  search = '';
  filter = 'active';
  editing: any = null;
  error = '';
  isAdmin = this.route.snapshot.data['role'] === 'ADMIN';
  constructor() {
    this.load();
  }
  get filtered() {
    return this.drugs.filter((d) => d.name.toLowerCase().includes(this.search.toLowerCase()));
  }
  load() {
    this.error = '';
    this.api.list(this.filter !== 'active').subscribe({
      next: (d) => {
        this.drugs =
          this.filter === 'inactive'
            ? d.filter((x) => !x.isActive)
            : this.filter === 'all'
              ? d
              : d.filter((x) => x.isActive);
        this.cdr.detectChanges();
      },
      error: (e) => {
        this.error = this.message(e);
        this.cdr.detectChanges();
      },
    });
  }
  private message(e: any) {
    return e.status === 0
      ? 'The gateway cannot be reached. Confirm the API Gateway is running on port 51946.'
      : `Unable to load inventory (HTTP ${e.status}).`;
  }
  open(d?: Drug) {
    this.editing = d
      ? { ...d }
      : { name: '', price: 0, quantityInStock: 0, isActive: true, supplierId: 0 };
  }
  save() {
    const request = {
      name: this.editing.name,
      price: +this.editing.price,
      quantityInStock: +this.editing.quantityInStock,
      isActive: true,
      supplierId: +this.editing.supplierId,
    };
    const call = this.editing.drugId
      ? this.api.update(this.editing.drugId, request)
      : this.api.create(request);
    call.subscribe({
      next: () => {
        this.editing = null;
        this.load();
      },
    });
  }
  activate(drug: Drug) {
    this.api
      .update(drug.drugId, {
        name: drug.name,
        price: drug.price,
        quantityInStock: drug.quantityInStock,
        isActive: true,
        supplierId: drug.supplierId,
      })
      .subscribe(() => this.load());
  }
  remove(id: number) {
    if (confirm('Deactivate this drug?')) this.api.remove(id).subscribe(() => this.load());
  }
}
