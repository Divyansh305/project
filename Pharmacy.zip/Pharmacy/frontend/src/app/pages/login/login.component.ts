import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: ` <section class="auth-page">
    <div class="auth-art">
      <div class="brand">
        <span class="brand-mark">Rx</span><span>Pharma<span class="brand-accent">Flow</span></span>
      </div>
      <div class="art-copy">
        <span class="eyebrow">SMARTER PHARMACY OPERATIONS</span>
        <h1>Care that moves<br /><em>forward.</em></h1>
        <p>One connected workspace for your pharmacy team, from inventory to patient care.</p>
      </div>
      <div class="art-footer">✦ Secure &nbsp; · &nbsp; Reliable &nbsp; · &nbsp; Connected</div>
    </div>
    <div class="auth-form-wrap">
      <div class="auth-form">
        <div class="mobile-brand"><span class="brand-mark">Rx</span><b>PharmaFlow</b></div>
        <span class="eyebrow">WELCOME BACK</span>
        <h2>Sign in to your workspace</h2>
        <p class="muted">Use your pharmacy credentials to continue.</p>
        <form (ngSubmit)="submit()">
          <label
            >Email address<input
              type="email"
              name="email"
              [(ngModel)]="email"
              placeholder="you@pharmacy.com"
              required /></label
          ><label
            >Password<input
              type="password"
              name="password"
              [(ngModel)]="password"
              placeholder="Enter your password"
              required
          /></label>
          @if (error) {
            <div class="alert error">{{ error }}</div>
          }
          <button class="btn primary full" [disabled]="loading">
            {{ loading ? 'Signing in…' : 'Sign in →' }}
          </button>
        </form>
        <p class="auth-note">Authorized access only. Contact your administrator for help.</p>
        <p class="auth-switch">New doctor? <a routerLink="/signup">Create an account</a></p>
      </div>
    </div>
  </section>`,
})
export class LoginComponent {
  private auth = inject(AuthService);
  email = '';
  password = '';
  loading = false;
  error = '';
  submit() {
    this.loading = true;
    this.error = '';
    this.auth.login({ email: this.email, password: this.password }).subscribe({
      error: (e) => {
        this.loading = false;
        this.error =
          e.status === 401 ? 'Invalid email or password.' : 'Unable to sign in. Please try again.';
      },
      next: () => (this.loading = false),
    });
  }
}
