import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { ReportsService } from '../../core/services/api.services';
@Component({
  standalone: true,
  imports: [CommonModule],
  template: `<section class="page">
    <div class="page-title">
      <div>
        <span class="eyebrow">INSIGHTS</span>
        <h2>Sales reports</h2>
        <p class="muted">Review completed sales across your pharmacy.</p>
      </div>
      <div class="button-group">
        <button class="btn ghost" (click)="print()">Print report</button
        ><button class="btn primary" (click)="download()">↓ Download CSV</button>
      </div>
    </div>
    <div class="stat-grid single">
      <div class="stat-card">
        <small>Total sales</small><strong>₹{{ total | number: '1.2-2' }}</strong
        ><span class="stat-meta">{{ sales.length }} completed transactions</span>
      </div>
    </div>
    <div class="panel table-panel">
      <table>
        <thead>
          <tr>
            <th>Order</th>
            <th>Amount</th>
            <th>Sale date</th>
          </tr>
        </thead>
        <tbody>
          @for (s of sales; track s.id) {
            <tr>
              <td>
                <b>#{{ s.orderId }}</b>
              </td>
              <td>₹{{ s.amount | number: '1.2-2' }}</td>
              <td>{{ s.saleDate | date: 'MMM d, y, h:mm a' }}</td>
            </tr>
          } @empty {
            <tr>
              <td colspan="3" class="empty">No sales recorded yet.</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  </section>`,
})
export class ReportsComponent {
  private api = inject(ReportsService);
  private cdr = inject(ChangeDetectorRef);
  sales: any[] = [];
  constructor() {
    this.api.list().subscribe({
      next: (s) => {
        this.sales = s;
        this.cdr.detectChanges();
      },
    });
  }
  get total() {
    return this.sales.reduce((x, s) => x + s.amount, 0);
  }
  download() {
    this.api.download().subscribe((blob) => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'sales-report.csv';
      a.click();
      URL.revokeObjectURL(a.href);
    });
  }
  print() {
    this.api.print().subscribe((html) => {
      const w = window.open();
      w?.document.write(html);
      w?.document.close();
      w?.print();
    });
  }
}
