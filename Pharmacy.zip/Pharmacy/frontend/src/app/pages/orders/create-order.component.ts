import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Drug, Order, RazorpayCheckoutResponse } from '../../core/models/models';
import { DrugsService, OrdersService } from '../../core/services/api.services';

declare global {
  interface Window {
    Razorpay?: new (options: Record<string, unknown>) => {
      open: () => void;
    };
  }
}

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `<section class="page narrow">
    <div class="page-title">
      <div>
        <span class="eyebrow">NEW REQUEST</span>
        <h2>Create an order</h2>
        <p class="muted">Select medicines and quantities for this prescription.</p>
      </div>
    </div>
    <div class="panel order-builder">
      @for (line of lines; track $index) {
        <div class="order-line">
          <select [(ngModel)]="line.drugId" name="drug{{ $index }}">
            <option [ngValue]="0">Select medicine</option>
            @for (d of drugs; track d.drugId) {
              <option [ngValue]="d.drugId">{{ d.name }} · ₹{{ d.price }}</option>
            }</select
          ><input type="number" min="1" [(ngModel)]="line.quantity" name="qty{{ $index }}" /><button
            class="text-btn danger-text"
            (click)="lines.splice($index, 1)"
          >
            Remove
          </button>
        </div>
      }
      <button class="btn ghost" (click)="lines.push({ drugId: 0, quantity: 1 })">
        + Add medicine
      </button>
      <div class="builder-footer">
        <strong>Estimated total: ₹{{ total | number: '1.2-2' }}</strong>
        @if (!createdOrder) {
          <button class="btn primary" [disabled]="!valid || busy" (click)="submit()">
            {{ busy ? 'Creating order…' : 'Continue to payment →' }}
          </button>
        } @else {
          <button class="btn primary" [disabled]="busy" (click)="pay()">
            {{ busy ? 'Opening checkout…' : 'Pay now →' }}
          </button>
        }
      </div>
      @if (error) {
        <div class="alert error">{{ error }}</div>
      }
      @if (success) {
        <div class="alert success">{{ success }}</div>
      }
    </div>
  </section>`,
})
export class CreateOrderComponent {
  private drugsApi = inject(DrugsService);
  private ordersApi = inject(OrdersService);
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);
  drugs: Drug[] = [];
  lines = [{ drugId: 0, quantity: 1 }];
  createdOrder: Order | null = null;
  busy = false;
  error = '';
  success = '';

  constructor() {
    this.drugsApi.list().subscribe({
      next: (d) => {
        this.drugs = d;
        this.cdr.detectChanges();
      },
    });
  }

  get total() {
    return this.lines.reduce(
      (sum, line) =>
        sum + (this.drugs.find((d) => d.drugId === line.drugId)?.price || 0) * line.quantity,
      0,
    );
  }

  get valid() {
    return (
      this.lines.length > 0 && this.lines.every((line) => line.drugId > 0 && line.quantity > 0)
    );
  }

  submit() {
    if (!this.valid || this.busy) return;
    this.busy = true;
    this.error = '';
    this.ordersApi.create(this.lines).subscribe({
      next: (order) => {
        this.createdOrder = order;
        this.busy = false;
        this.success = `Order #${order.id} created. Complete payment to continue.`;
        this.cdr.detectChanges();
      },
      error: (error) => {
        this.busy = false;
        this.error = error.error?.message || 'Unable to create order.';
        this.cdr.detectChanges();
      },
    });
  }

  pay() {
    if (!this.createdOrder || this.busy) return;
    if (!window.Razorpay) {
      this.error =
        'Razorpay Checkout could not be loaded. Check your internet connection and reload.';
      return;
    }
    this.busy = true;
    this.error = '';
    this.ordersApi.createRazorpayOrder(this.createdOrder.id).subscribe({
      next: (checkout) => this.openCheckout(checkout),
      error: (error) => {
        this.busy = false;
        this.error = error.error?.message || 'Unable to start payment.';
        this.cdr.detectChanges();
      },
    });
  }

  private openCheckout(checkout: RazorpayCheckoutResponse) {
    let settled = false;
    const checkoutWindow = new window.Razorpay!({
      key: checkout.keyId,
      amount: checkout.amount,
      currency: checkout.currency,
      name: 'PharmaFlow',
      description: `Pharmacy order #${this.createdOrder?.id}`,
      order_id: checkout.orderId,
      handler: (response: {
        razorpay_order_id: string;
        razorpay_payment_id: string;
        razorpay_signature: string;
      }) => {
        this.ordersApi
          .verifyRazorpayPayment(this.createdOrder!.id, {
            razorpayOrderId: response.razorpay_order_id,
            razorpayPaymentId: response.razorpay_payment_id,
            razorpaySignature: response.razorpay_signature,
          })
          .subscribe({
            next: (result) => {
              settled = true;
              this.busy = false;
              this.success = `Payment successful. Reference: ${result.transactionReference || response.razorpay_payment_id}`;
              this.cdr.detectChanges();
              setTimeout(() => this.router.navigateByUrl('/doctor/orders'), 1800);
            },
            error: (error) => {
              this.busy = false;
              this.error = error.error?.message || 'Payment verification failed.';
              this.cdr.detectChanges();
            },
          });
      },
      modal: {
        ondismiss: () => {
          if (settled) return;
          this.ordersApi.failRazorpayPayment(this.createdOrder!.id).subscribe({
            complete: () => {
              this.busy = false;
              this.error =
                'Payment was cancelled before completion. If the checkout was blank, allow checkout.razorpay.com in the browser and try again.';
              this.cdr.detectChanges();
            },
            error: () => {
              this.busy = false;
              this.error =
                'Payment was cancelled, but the order could not be released automatically.';
              this.cdr.detectChanges();
            },
          });
        },
      },
    });
    this.busy = false;
    this.cdr.detectChanges();
    checkoutWindow.open();
  }
}
