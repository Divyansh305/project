import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Order } from '../../core/models/models';
import { DrugsService, OrdersService } from '../../core/services/api.services';

@Component({
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `<section class="page narrow">
    @if (loading) {
      <div class="panel empty">Loading order…</div>
    } @else if (error) {
      <div class="alert error">{{ error }}</div>
    } @else if (order) {
      <a class="back-link" routerLink="/doctor/orders">← Back to order history</a>
      <div class="page-title">
        <div>
          <span class="eyebrow">ORDER DETAILS</span>
          <h2>Order #{{ order.id }}</h2>
          <p class="muted">Created {{ order.createdAt | date: 'MMM d, y, h:mm a' }}</p>
        </div>
        <span class="status" [class]="order.status.toLowerCase()">{{
          order.status.replace('_', ' ')
        }}</span>
      </div>
      <div class="stat-grid single">
        <div class="stat-card">
          <small>Total amount</small><strong>₹{{ order.totalAmount | number: '1.2-2' }}</strong
          ><span class="stat-meta">{{ order.items?.length || 0 }} items</span>
        </div>
        <div class="stat-card">
          <small>Doctor</small><strong class="small-stat">{{ order.doctorNameSnapshot }}</strong
          ><span class="stat-meta">Doctor ID #{{ order.doctorId }}</span>
        </div>
      </div>
      <div class="panel">
        <span class="eyebrow">ITEMS</span>
        <h3>Prescription items</h3>
        <div class="detail-items">
          @for (item of order.items; track item.id) {
            <div class="detail-item">
              <div>
                <b>{{ drugName(item.drugId) }}</b
                ><small>Drug ID #{{ item.drugId }}</small>
              </div>
              <span>{{ item.quantity }} × ₹{{ item.unitPriceAtOrder | number: '1.2-2' }}</span
              ><strong>₹{{ item.quantity * item.unitPriceAtOrder | number: '1.2-2' }}</strong>
            </div>
          } @empty {
            <div class="empty">No items returned.</div>
          }
        </div>
      </div>
      <div class="panel timeline">
        <span class="eyebrow">WORKFLOW</span>
        <h3>Order status</h3>
        <div class="timeline-row">
          <span [class.done]="hasReached('NEW')">1</span><b>New</b><i></i
          ><span [class.done]="hasReached('VERIFIED')">2</span><b>Verified</b><i></i
          ><span [class.done]="hasReached('COMPLETED')">3</span><b>Completed</b>
        </div>
        @if (order.cancelledAt) {
          <p class="muted">Cancelled {{ order.cancelledAt | date: 'medium' }}</p>
        }
      </div>
    }
  </section>`,
})
export class OrderDetailsComponent {
  private ordersApi = inject(OrdersService);
  private drugsApi = inject(DrugsService);
  private route = inject(ActivatedRoute);
  private cdr = inject(ChangeDetectorRef);
  order: Order | null = null;
  drugs = new Map<number, string>();
  loading = true;
  error = '';

  constructor() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.drugsApi
      .list()
      .subscribe({
        next: (drugs) => drugs.forEach((drug) => this.drugs.set(drug.drugId, drug.name)),
      });
    this.ordersApi.get(id).subscribe({
      next: (order) => {
        this.order = order;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: (error) => {
        this.loading = false;
        this.error = error.status === 404 ? 'Order not found.' : 'Unable to load this order.';
        this.cdr.detectChanges();
      },
    });
  }

  drugName(id: number) {
    return this.drugs.get(id) || `Drug #${id}`;
  }
  hasReached(status: string) {
    const rank: Record<string, number> = { NEW: 1, VERIFIED: 2, PICKED_UP: 3, COMPLETED: 3 };
    return (rank[this.order?.status || ''] || 0) >= rank[status];
  }
}
