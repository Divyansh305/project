import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Order } from '../../core/models/models';
import { OrdersService } from '../../core/services/api.services';
@Component({
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `<section class="page">
    <div class="page-title">
      <div>
        <span class="eyebrow">FULFILMENT</span>
        <h2>{{ isAdmin ? 'Orders' : 'Order history' }}</h2>
        <p class="muted">
          {{
            isAdmin
              ? 'Review and process pharmacy orders.'
              : 'Track your prescription orders and payment status.'
          }}
        </p>
      </div>
      @if (!isAdmin) {
        <a class="btn primary" routerLink="/doctor/orders/create">+ Create order</a>
      }
    </div>
    @if (message) {
      <div class="alert success">{{ message }}</div>
    }
    @if (error) {
      <div class="alert error">{{ error }}</div>
    }
    <div class="toolbar">
      <select (change)="load($any($event.target).value)">
        <option value="">All statuses</option>
        <option>NEW</option>
        <option>VERIFIED</option>
        <option>PICKED_UP</option>
        <option>COMPLETED</option>
        <option>CANCELLED</option></select
      ><button class="btn ghost" (click)="load()">Refresh</button>
    </div>
    <div class="panel table-panel">
      <table>
        <thead>
          <tr>
            <th>Order</th>
            <th>Doctor</th>
            <th>Total</th>
            <th>Items</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          @for (o of orders; track o.id) {
            <tr>
              <td>
                <a class="order-link" [routerLink]="isAdmin ? null : ['/doctor/orders', o.id]"
                  ><b>#{{ o.id }}</b></a
                ><small>{{ o.createdAt | date: 'MMM d, y, h:mm a' }}</small>
              </td>
              <td>{{ o.doctorNameSnapshot }}</td>
              <td>₹{{ o.totalAmount | number: '1.2-2' }}</td>
              <td>{{ o.items?.length || 0 }} line items</td>
              <td>
                <span class="status" [class]="o.status.toLowerCase()">{{
                  o.status.replace('_', ' ')
                }}</span>
              </td>
              <td>
                <div class="actions">
                  @if (isAdmin && o.status === 'NEW') {
                    <button class="text-btn" (click)="action('verify', o.id)">Verify</button>
                  }
                  @if (isAdmin && o.status === 'VERIFIED') {
                    <button class="text-btn" (click)="action('pickup', o.id)">Pick up</button>
                  }
                  @if (o.status === 'NEW' || o.status === 'VERIFIED') {
                    <button class="text-btn danger-text" (click)="action('cancel', o.id)">
                      Cancel
                    </button>
                  }
                </div>
              </td>
            </tr>
          } @empty {
            <tr>
              <td colspan="6" class="empty">No orders found.</td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  </section>`,
})
export class OrdersComponent {
  private api = inject(OrdersService);
  private route = inject(ActivatedRoute);
  private cdr = inject(ChangeDetectorRef);
  orders: Order[] = [];
  message = '';
  error = '';
  isAdmin = this.route.snapshot.data['role'] === 'ADMIN';
  constructor() {
    this.load();
  }
  load(status?: string) {
    this.api.list(status).subscribe({
      next: (o) => {
        this.orders = o;
        this.cdr.detectChanges();
      },
    });
  }
  action(type: string, id: number) {
    this.message = '';
    this.error = '';
    const call =
      type === 'verify'
        ? this.api.verify(id)
        : type === 'pickup'
          ? this.api.pickup(id)
          : this.api.cancel(id);
    call.subscribe({
      next: () => {
        this.message =
          type === 'cancel'
            ? 'Order cancelled and payment refund processed where applicable.'
            : 'Order updated successfully.';
        this.load();
      },
      error: (e) => {
        this.error = e.error?.message || 'Unable to update the order.';
        this.cdr.detectChanges();
      },
    });
  }
}
