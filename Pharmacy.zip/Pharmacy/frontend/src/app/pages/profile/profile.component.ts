import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="page narrow">
      <div class="page-title">
        <div>
          <span class="eyebrow">ACCOUNT</span>
          <h2>My profile</h2>
          <p class="muted">Review your pharmacy account details.</p>
        </div>
      </div>
      <div class="profile-card panel">
        <div class="profile-hero">
          <span class="profile-avatar">{{ (auth.userName() || 'U').charAt(0) }}</span>
          <div>
            <h3>{{ auth.userName() || 'User' }}</h3>
            <span class="status active">{{ auth.role() }}</span>
          </div>
        </div>
        <div class="profile-details">
          <div>
            <span class="eyebrow">FULL NAME</span
            ><strong>{{ auth.userName() || 'Not available' }}</strong>
          </div>
          <div>
            <span class="eyebrow">EMAIL ADDRESS</span
            ><strong>{{ auth.userEmail() || 'Not available' }}</strong>
          </div>
          <div>
            <span class="eyebrow">ACCOUNT ROLE</span><strong>{{ auth.role() }}</strong>
          </div>
          <div>
            <span class="eyebrow">USER ID</span><strong>#{{ auth.userId() }}</strong>
          </div>
        </div>
        <div class="profile-actions">
          <a class="btn ghost" [routerLink]="auth.role() === 'ADMIN' ? '/admin' : '/doctor'"
            >Back to dashboard</a
          >
          <button class="btn primary" type="button" (click)="auth.logout()">Sign out</button>
        </div>
      </div>
    </section>
  `,
})
export class ProfileComponent {
  readonly auth = inject(AuthService);
}
