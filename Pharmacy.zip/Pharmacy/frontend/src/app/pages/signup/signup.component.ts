import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: ` <section class="auth-page">
    <div class="auth-art">
      <div class="brand">
        <span class="brand-mark">Rx</span><span>Pharma<span class="brand-accent">Flow</span></span>
      </div>
      <div class="art-copy">
        <span class="eyebrow">JOIN PHARMAFLOW</span>
        <h1>Start caring<br /><em>smarter.</em></h1>
        <p>Create your Doctor workspace account and begin managing prescriptions.</p>
      </div>
      <div class="art-footer">✦ Secure &nbsp; · &nbsp; Reliable &nbsp; · &nbsp; Connected</div>
    </div>
    <div class="auth-form-wrap">
      <div class="auth-form">
        <div class="mobile-brand"><span class="brand-mark">Rx</span><b>PharmaFlow</b></div>
        <span class="eyebrow">NEW ACCOUNT</span>
        <h2>Create your account</h2>
        <p class="muted">Doctor accounts can browse inventory and create orders.</p>
        <form (ngSubmit)="submit()">
          <label
            >Full name<input
              type="text"
              name="name"
              [(ngModel)]="name"
              placeholder="Your name"
              required /></label
          ><label
            >Email address<input
              type="email"
              name="email"
              [(ngModel)]="email"
              placeholder="you@pharmacy.com"
              required /></label
          ><label
            >Password<input
              type="password"
              name="password"
              [(ngModel)]="password"
              placeholder="At least 8 characters"
              minlength="8"
              required
          /></label>
          @if (error) {
            <div class="alert error">{{ error }}</div>
          }
          <button class="btn primary full" [disabled]="loading">
            {{ loading ? 'Creating account…' : 'Create account →' }}
          </button>
        </form>
        <p class="auth-note">Admin accounts are provisioned by an administrator.</p>
        <p class="auth-switch">Already registered? <a routerLink="/login">Sign in</a></p>
      </div>
    </div>
  </section>`,
})
export class SignupComponent {
  private auth = inject(AuthService);
  name = '';
  email = '';
  password = '';
  loading = false;
  error = '';
  submit() {
    this.loading = true;
    this.error = '';
    this.auth.signup({ name: this.name, email: this.email, password: this.password }).subscribe({
      error: (e) => {
        this.loading = false;
        this.error =
          e.status === 409
            ? 'An account with this email already exists.'
            : e.status === 400
              ? 'Enter a valid name, email, and password.'
              : 'Unable to create your account. Please try again.';
      },
      next: () => (this.loading = false),
    });
  }
}
