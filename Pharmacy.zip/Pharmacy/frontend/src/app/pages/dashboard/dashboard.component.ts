import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { DrugsService, OrdersService, ReportsService } from '../../core/services/api.services';
import { forkJoin } from 'rxjs';
@Component({
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: ` <section class="page">
    <div class="welcome">
      <div>
        <span class="eyebrow">OVERVIEW</span>
        <h2>Good day, {{ auth.userName() || 'there' }} <span>✦</span></h2>
        <p class="muted">Here’s what’s happening across your pharmacy today.</p>
      </div>
      <a
        class="btn primary"
        [routerLink]="auth.role() === 'DOCTOR' ? '/doctor/orders/create' : '/admin/drugs'"
        >{{ auth.role() === 'DOCTOR' ? '+ Create order' : '+ Add new drug' }}</a
      >
    </div>
    <div class="stat-grid">
      @if (auth.role() === 'DOCTOR') {
        <div class="stat-card">
          <span class="stat-icon blue">⇄</span><small>Total orders</small
          ><strong>{{ orders }}</strong
          ><span class="stat-meta">Your order history</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon gold">◷</span><small>New orders</small
          ><strong>{{ newOrders }}</strong
          ><span class="stat-meta">Awaiting review</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon teal">✓</span><small>Completed</small
          ><strong>{{ completed }}</strong
          ><span class="stat-meta">Picked up or completed</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon violet">₹</span><small>Total order value</small
          ><strong>₹{{ totalValue | number: '1.0-0' }}</strong
          ><span class="stat-meta">From returned orders</span>
        </div>
      } @else {
        <div class="stat-card">
          <span class="stat-icon teal">▦</span><small>Active drugs</small
          ><strong>{{ drugs }}</strong
          ><span class="stat-meta">Live inventory</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon blue">⇄</span><small>All orders</small><strong>{{ orders }}</strong
          ><span class="stat-meta">Latest records</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon gold">◷</span><small>Pending review</small
          ><strong>{{ pending }}</strong
          ><span class="stat-meta">Needs attention</span>
        </div>
        <div class="stat-card">
          <span class="stat-icon violet">↗</span><small>Sales records</small
          ><strong>{{ sales }}</strong
          ><span class="stat-meta">Completed sales</span>
        </div>
      }
    </div>
    <div class="content-grid">
      <div class="panel">
        <div class="panel-head">
          <div>
            <span class="eyebrow">RECENT ACTIVITY</span>
            <h3>Latest orders</h3>
          </div>
          <a [routerLink]="auth.role() === 'ADMIN' ? '/admin/orders' : '/doctor/orders'"
            >View all →</a
          >
        </div>
        @if (recent.length) {
          @for (order of recent; track order.id) {
            <div class="activity-row">
              <span class="order-icon">#</span>
              <div>
                <b>Order #{{ order.id }}</b
                ><small
                  >{{ order.doctorNameSnapshot }} · {{ order.items?.length || 0 }} items</small
                >
              </div>
              <span class="status" [class]="order.status.toLowerCase()">{{
                order.status.replace('_', ' ')
              }}</span
              ><strong>₹{{ order.totalAmount | number: '1.2-2' }}</strong>
            </div>
          }
        } @else {
          <div class="empty">No orders to display yet.</div>
        }
      </div>
      <div class="panel quick">
        <span class="eyebrow">QUICK ACTIONS</span>
        <h3>Get things done</h3>
        <a [routerLink]="auth.role() === 'ADMIN' ? '/admin/drugs' : '/doctor/drugs'"
          >▦ <span>Browse inventory</span><b>→</b></a
        ><a [routerLink]="auth.role() === 'ADMIN' ? '/admin/orders' : '/doctor/orders'"
          >⇄ <span>Manage orders</span><b>→</b></a
        >
        @if (auth.role() === 'ADMIN') {
          <a routerLink="/admin/reports">▥ <span>View sales report</span><b>→</b></a>
        }
      </div>
    </div>
  </section>`,
})
export class DashboardComponent {
  auth = inject(AuthService);
  private drugApi = inject(DrugsService);
  private orderApi = inject(OrdersService);
  private reportApi = inject(ReportsService);
  private cdr = inject(ChangeDetectorRef);
  drugs = 0;
  orders = 0;
  pending = 0;
  sales = 0;
  newOrders = 0;
  completed = 0;
  totalValue = 0;
  recent: any[] = [];
  constructor() {
    if (this.auth.role() === 'ADMIN') {
      forkJoin({
        drugs: this.drugApi.list(),
        orders: this.orderApi.list(),
        sales: this.reportApi.list(),
      }).subscribe({
        next: (x) => this.applyDashboardData(x.drugs, x.orders, x.sales.length),
        error: () => this.cdr.detectChanges(),
      });
    } else {
      forkJoin({ drugs: this.drugApi.list(), orders: this.orderApi.list() }).subscribe({
        next: (x) => this.applyDashboardData(x.drugs, x.orders, 0),
        error: () => this.cdr.detectChanges(),
      });
    }
  }
  private applyDashboardData(drugs: any[], orders: any[], sales: number) {
    this.drugs = drugs.length;
    this.recent = orders.slice(0, 5);
    this.orders = orders.length;
    this.pending = orders.filter((o) => o.status === 'NEW' || o.status === 'VERIFIED').length;
    this.newOrders = orders.filter((o) => o.status === 'NEW').length;
    this.completed = orders.filter(
      (o) => o.status === 'PICKED_UP' || o.status === 'COMPLETED',
    ).length;
    this.totalValue = orders.reduce((sum, order) => sum + order.totalAmount, 0);
    this.sales = sales;
    this.cdr.detectChanges();
  }
}
