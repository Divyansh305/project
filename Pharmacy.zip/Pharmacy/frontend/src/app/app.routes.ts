import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'signup',
    loadComponent: () => import('./pages/signup/signup.component').then((m) => m.SignupComponent),
  },
  {
    path: 'admin',
    canActivate: [authGuard, roleGuard('ADMIN')],
    loadComponent: () =>
      import('./pages/dashboard/dashboard.component').then((m) => m.DashboardComponent),
    data: { role: 'ADMIN' },
  },
  {
    path: 'admin/drugs',
    canActivate: [authGuard, roleGuard('ADMIN')],
    loadComponent: () => import('./pages/drugs/drugs.component').then((m) => m.DrugsComponent),
    data: { role: 'ADMIN' },
  },
  {
    path: 'admin/suppliers',
    canActivate: [authGuard, roleGuard('ADMIN')],
    loadComponent: () =>
      import('./pages/suppliers/suppliers.component').then((m) => m.SuppliersComponent),
  },
  {
    path: 'admin/orders',
    canActivate: [authGuard, roleGuard('ADMIN')],
    loadComponent: () => import('./pages/orders/orders.component').then((m) => m.OrdersComponent),
    data: { role: 'ADMIN' },
  },
  {
    path: 'admin/reports',
    canActivate: [authGuard, roleGuard('ADMIN')],
    loadComponent: () =>
      import('./pages/reports/reports.component').then((m) => m.ReportsComponent),
  },
  {
    path: 'admin/profile',
    canActivate: [authGuard, roleGuard('ADMIN')],
    loadComponent: () =>
      import('./pages/profile/profile.component').then((m) => m.ProfileComponent),
    data: { role: 'ADMIN' },
  },
  {
    path: 'doctor',
    canActivate: [authGuard, roleGuard('DOCTOR')],
    loadComponent: () =>
      import('./pages/dashboard/dashboard.component').then((m) => m.DashboardComponent),
    data: { role: 'DOCTOR' },
  },
  {
    path: 'doctor/drugs',
    canActivate: [authGuard, roleGuard('DOCTOR')],
    loadComponent: () => import('./pages/drugs/drugs.component').then((m) => m.DrugsComponent),
    data: { role: 'DOCTOR' },
  },
  {
    path: 'doctor/orders',
    canActivate: [authGuard, roleGuard('DOCTOR')],
    loadComponent: () => import('./pages/orders/orders.component').then((m) => m.OrdersComponent),
    data: { role: 'DOCTOR' },
  },
  {
    path: 'doctor/orders/create',
    canActivate: [authGuard, roleGuard('DOCTOR')],
    loadComponent: () =>
      import('./pages/orders/create-order.component').then((m) => m.CreateOrderComponent),
  },
  {
    path: 'doctor/orders/:id',
    canActivate: [authGuard, roleGuard('DOCTOR')],
    loadComponent: () =>
      import('./pages/orders/order-details.component').then((m) => m.OrderDetailsComponent),
  },
  {
    path: 'doctor/profile',
    canActivate: [authGuard, roleGuard('DOCTOR')],
    loadComponent: () =>
      import('./pages/profile/profile.component').then((m) => m.ProfileComponent),
    data: { role: 'DOCTOR' },
  },
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: '**', redirectTo: 'login' },
];
