# PharmacyFlow frontend

This Angular application communicates only with the API Gateway at
`http://localhost:51946/api`. It supports JWT login, role-based Admin and
Doctor workspaces, inventory and supplier CRUD, order processing, and sales
reports.

## Run locally

1. Start the four backend services using the commands in the repository root
   [README.md](../README.md).
2. From this folder, run `npm start`.
3. Open `http://localhost:4200`.

The gateway allows the Angular development origin (`http://localhost:4200`)
through its CORS policy. The frontend does not connect to SQL Server or to any
individual microservice port.
