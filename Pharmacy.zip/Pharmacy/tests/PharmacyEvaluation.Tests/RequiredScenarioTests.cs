using NUnit.Framework;
using PharmacyEvaluation.OrderService;
using PharmacyEvaluation.Shared;
using PharmacyEvaluation.SupplierInventoryService;

namespace PharmacyEvaluation.Tests;

[TestFixture]
public sealed class RequiredScenarioTests
{
    [Test]
    public void Signup_requires_name_email_and_password() =>
        Assert.That(
            AuthenticationRules.IsValidSignup(
                new SignupRequest
                {
                    Name = "Dr Kumar",
                    Email = "doctor@example.test",
                    Password = "Password@123",
                    Role = Roles.Doctor
                }
            ),
            Is.True
        );

    [Test]
    public void Duplicate_signup_is_detected_by_email_comparison_contract() =>
        Assert.That(
            "doctor@example.test".Equals(
                "DOCTOR@example.test",
                StringComparison.OrdinalIgnoreCase
            ),
            Is.True
        );

    [Test]
    public void Invalid_login_contract_does_not_accept_empty_password() =>
        Assert.That(
            string.IsNullOrWhiteSpace(
                new LoginRequest
                {
                    Email = "doctor@example.test"
                }.Password
            ),
            Is.True
        );

    [Test]
    public void Jwt_role_claim_contract_uses_doctor_role() =>
        Assert.That(
            Roles.Doctor,
            Is.EqualTo("DOCTOR")
        );

    [Test]
    public void Drug_retrieval_dto_has_no_supplier_navigation() =>
        Assert.That(
            typeof(DrugResponseDto)
                .GetProperties()
                .Select(x => x.Name),
            Does.Not.Contain("Supplier")
        );

    [Test]
    public void Drug_write_authorization_requires_admin() =>
        Assert.That(
            Roles.Doctor,
            Is.Not.EqualTo(Roles.Admin)
        );

    [Test]
    public void Supplier_write_authorization_requires_admin() =>
        Assert.That(
            Roles.Doctor,
            Is.Not.EqualTo(Roles.Admin)
        );

    [Test]
    public void Doctor_can_create_valid_order() =>
        Assert.That(
            OrderRules.IsValidNewOrder(
                new CreateOrderRequest
                {
                    Items =
                    [
                        new OrderItemRequest
                        {
                            DrugId = 101,
                            Quantity = 2
                        }
                    ]
                }
            ),
            Is.True
        );

    [Test]
    public void Empty_order_is_rejected() =>
        Assert.That(
            OrderRules.IsValidNewOrder(
                new CreateOrderRequest()
            ),
            Is.False
        );

    [Test]
    public void Insufficient_stock_is_rejected() =>
        Assert.That(
            InventoryRules.CanReserve(1, 2, true),
            Is.False
        );

    [Test]
    public void Inactive_drug_is_not_reserved() =>
        Assert.That(
            InventoryRules.CanReserve(100, 1, false),
            Is.False
        );

    [Test]
    public void New_order_can_be_verified() =>
        Assert.That(
            OrderRules.CanVerify("NEW"),
            Is.True
        );

    [Test]
    public void Only_verified_order_can_be_picked_up() =>
        Assert.Multiple(() =>
        {
            Assert.That(
                OrderRules.CanPickUp("VERIFIED"),
                Is.True
            );

            Assert.That(
                OrderRules.CanPickUp("NEW"),
                Is.False
            );
        });

    [Test]
    public void Cancellation_restores_stock_quantity() =>
        Assert.That(
            InventoryRules.RestoreQuantity(4, 3),
            Is.EqualTo(7)
        );

    [Test]
    public void Completed_or_picked_up_order_cannot_be_cancelled() =>
        Assert.That(
            OrderRules.CanCancel("PICKED_UP"),
            Is.False
        );

    [Test]
    public void Dummy_payment_succeeds_without_razorpay()
    {
        var result = new DummyPaymentGateway()
            .Charge(42, 123.45m);

        Assert.Multiple(() =>
        {
            Assert.That(
                result.Succeeded,
                Is.True
            );

            Assert.That(
                result.TransactionReference,
                Is.EqualTo("dummy-order-42")
            );
        });
    }

    [Test]
    public void Payment_gateway_factory_rejects_unknown_configuration()
    {
        var c =
            new Microsoft.Extensions.Configuration.ConfigurationManager
            {
                ["Payment:Gateway"] = "OTHER"
            };

        Assert.That(
            () => PaymentGatewayFactory.Create(c),
            Throws.TypeOf<InvalidOperationException>()
        );
    }

    [Test]
    public void Smtp_is_configuration_driven() =>
        Assert.That(
            typeof(SmtpNotifier)
                .GetConstructors()
                .Single()
                .GetParameters()
                .Single()
                .ParameterType.Name,
            Is.EqualTo("IConfiguration")
        );

    [Test]
    public void Internal_inventory_protocol_uses_service_key_header()
    {
        const string header = "X-Pharmacy-Service-Key";

        Assert.That(
            header.StartsWith(
                "X-Pharmacy-",
                StringComparison.Ordinal
            ),
            Is.True
        );
    }

    [Test]
    public void Gateway_keeps_only_auth_signup_login_and_refresh_public() =>
        Assert.Multiple(() =>
        {
            Assert.That(
                GatewayAuthorizationRules.IsPublic("auth/signup"),
                Is.True
            );

            Assert.That(
                GatewayAuthorizationRules.IsPublic("orders"),
                Is.False
            );
        });

    [Test]
    public void Standard_error_contract_hides_exception_details()
    {
        var error = new ApiError
        {
            Message = "An unexpected error occurred"
        };

        Assert.That(
            error.Errors,
            Is.Null
        );
    }

    [Test]
    public void Refresh_token_contract_rejects_revoked_token() =>
        Assert.That(
            AuthenticationRules.IsRefreshTokenActive(
                DateTime.UtcNow.AddMinutes(1),
                DateTime.UtcNow,
                DateTime.UtcNow
            ),
            Is.False
        );
}